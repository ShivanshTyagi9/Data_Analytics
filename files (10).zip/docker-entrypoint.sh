#!/bin/bash
# docker-entrypoint.sh — runs as root, starts Tor, then drops to robin for Streamlit
set -e

echo "=================================================="
echo "  Robin v2 — Dark Web OSINT Platform"
echo "=================================================="

# ── 1. Start Tor as debian-tor user ──────────────────────────────────────────
echo "[*] Starting Tor daemon..."
runuser -u debian-tor -- tor -f /etc/tor/torrc &

# ── 2. Wait for Tor SOCKS port ───────────────────────────────────────────────
echo "[*] Waiting for Tor SOCKS proxy on 127.0.0.1:9050 ..."
MAX_WAIT=60
COUNT=0
until nc -z 127.0.0.1 9050 2>/dev/null; do
  sleep 1
  COUNT=$((COUNT + 1))
  if [ "$COUNT" -ge "$MAX_WAIT" ]; then
    echo "[!] WARNING: Tor did not come up within ${MAX_WAIT}s."
    echo "[!] Dark-web scraping will fail. Check: docker compose logs robin"
    break
  fi
done

if nc -z 127.0.0.1 9050 2>/dev/null; then
  echo "[✓] Tor SOCKS proxy ready (${COUNT}s elapsed)"
else
  echo "[!] Tor not reachable — continuing anyway"
fi

# ── 3. Load .env if present ──────────────────────────────────────────────────
if [ -f /app/.env ]; then
  set -a
  source /app/.env
  set +a
  echo "[✓] Environment loaded from /app/.env"
fi

# ── 4. Warn if OpenAI key missing ────────────────────────────────────────────
if [ -z "$OPENAI_API_KEY" ]; then
  echo ""
  echo "  ┌──────────────────────────────────────────────────────┐"
  echo "  │  WARNING: OPENAI_API_KEY is not set.                 │"
  echo "  │  LLM features will be unavailable.                   │"
  echo "  │  Set it in your .env file or pass -e OPENAI_API_KEY  │"
  echo "  └──────────────────────────────────────────────────────┘"
  echo ""
fi

# ── 5. Launch Streamlit as non-root robin user ────────────────────────────────
echo "[*] Starting Streamlit as user 'robin' on port 8501..."
echo "[*] Open: http://localhost:8501"
echo ""

exec runuser -u robin -- streamlit run /app/ui.py \
  --server.port=8501 \
  --server.address=0.0.0.0 \
  --server.headless=true \
  --server.fileWatcherType=none \
  --browser.gatherUsageStats=false \
  --server.enableCORS=false \
  --server.enableXsrfProtection=true
