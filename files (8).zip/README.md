# Robin v2 — Dark Web OSINT Platform

AI-powered dark web intelligence platform using **only free data sources** + OpenAI for LLM analysis.

---

## Quick Start

```bash
# 1. Install Tor
sudo apt install tor && sudo systemctl start tor   # Linux
brew install tor && brew services start tor        # macOS

# 2. Install Python dependencies
pip install -r requirements.txt

# 3. Configure API keys
cp .env.example .env
# Edit .env and add at minimum: OPENAI_API_KEY

# 4. Run
streamlit run ui.py
```

---

## .env Configuration

```env
# ── REQUIRED ─────────────────────────────────────────────────────
OPENAI_API_KEY=sk-...
OPENAI_MODEL=gpt-4o-mini        # or gpt-4o, gpt-4.1 etc.

# ── OPTIONAL (all free accounts) ────────────────────────────────
OTX_API_KEY=...                 # free: otx.alienvault.com
ABUSEIPDB_KEY=...               # free: abuseipdb.com
URLSCAN_KEY=...                 # free: urlscan.io
ETHERSCAN_KEY=...               # free: etherscan.io

# ── TOR (default values work for standard Tor install) ──────────
TOR_SOCKS_HOST=127.0.0.1
TOR_SOCKS_PORT=9050
TOR_CONTROL_PORT=9051
```

---

## Free Data Sources

| Source | What it provides | Key needed? |
|--------|-----------------|-------------|
| 20 Onion Search Engines | Dark web content via Tor | ❌ None |
| Ahmia.fi clearweb | Dark web index (Tor fallback) | ❌ None |
| Shodan InternetDB | Open ports + CVEs for any IP | ❌ None (forever free) |
| ip-api.com | IP geolocation + ASN | ❌ None (45 req/min) |
| AlienVault OTX | Threat pulses + indicators | ⬜ Optional (free) |
| urlscan.io | Domain scan history | ⬜ Optional (free) |
| AbuseIPDB | IP abuse reputation | ⬜ Optional (free) |
| psbdmp.ws | Pastebin dump index | ❌ None |
| Blockchain.info | Bitcoin address lookup | ❌ None |
| Etherscan | Ethereum address lookup | ⬜ Optional (free) |
| OpenAI GPT-4o | Query refinement, filtering, report | ✅ Required |

---

## Architecture

```
User Query
    │
    ▼
[LLM: refine_query]          → optimised 5-word search string
    │
    ▼
[search.py]                  → 20 onion engines + Ahmia.fi in parallel (via Tor)
    │
    ▼
[LLM: filter_results]        → top-20 relevant links selected by GPT
    │
    ▼
[scrape.py]                  → scrape pages via Tor · honeypot/CAPTCHA filter
    │
    ├──► [entities.py]       → regex IOC extraction (IPs, crypto, CVEs, hashes…)
    │
    ├──► [osint.py]          → free enrichment (Shodan, ip-api, OTX, urlscan, etc.)
    │
    ├──► [osint.py]          → OTX pulse search + paste-site search
    │
    └──► [LLM: generate_summary] → streaming AI intelligence report
              │
              ▼
         [report.py]         → HTML + Markdown + IOC JSON export
```

---

## New in v2 vs Original Robin

| Feature | v1 | v2 |
|---------|----|----|
| LLM providers | 6 (OpenAI, Anthropic, Google, Ollama, llama.cpp, OpenRouter) | OpenAI only (as requested) |
| Onion search engines | 16 | 20 + Ahmia clearweb fallback |
| Content quality scoring | ❌ | ✅ honeypot + CAPTCHA detection |
| IOC extraction | ❌ | ✅ 13 entity types (regex) |
| Free OSINT enrichment | ❌ | ✅ Shodan, ip-api, OTX, urlscan, blockchain |
| OTX pulse search | ❌ | ✅ |
| Paste site search | ❌ | ✅ psbdmp.ws |
| Tor exit IP verification | ❌ | ✅ |
| HTML report export | ❌ | ✅ |
| IOC JSON export | ❌ | ✅ |
| Analysis profiles | 4 | 4 (improved prompts + MITRE ATT&CK) |
| UI layout | Single page | 5 tabs (Search, Entities, Enrichment, Feeds, Report) |
