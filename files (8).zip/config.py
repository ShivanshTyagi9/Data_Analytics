import os
from dotenv import load_dotenv

load_dotenv()

# ── LLM (OpenAI / ChatGPT only) ─────────────────────────────────────────────
OPENAI_API_KEY   = os.getenv("OPENAI_API_KEY")
OPENAI_MODEL     = os.getenv("OPENAI_MODEL", "gpt-4o-mini")   # cheap default; override to gpt-4o
OPENAI_BASE_URL  = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")

# ── Tor proxy ────────────────────────────────────────────────────────────────
TOR_SOCKS_HOST   = os.getenv("TOR_SOCKS_HOST", "127.0.0.1")
TOR_SOCKS_PORT   = int(os.getenv("TOR_SOCKS_PORT", "9050"))
TOR_CONTROL_PORT = int(os.getenv("TOR_CONTROL_PORT", "9051"))
TOR_CONTROL_PASS = os.getenv("TOR_CONTROL_PASS", "")

# ── Free enrichment services (no key needed unless noted) ───────────────────
# Shodan InternetDB  → https://internetdb.shodan.io/{ip}          [free, no key]
# ip-api.com         → http://ip-api.com/json/{ip}?fields=...     [free, 45 req/min]
# AbuseIPDB          → https://api.abuseipdb.com/api/v2/check     [free key, 1k/day]
# AlienVault OTX     → https://otx.alienvault.com/api/v1          [free, optional key]
# urlscan.io         → https://urlscan.io/api/v1/search/          [free, no key for search]
# psbdmp.ws          → https://psbdmp.ws/api/v3/search/{q}        [free, no key]
# Ahmia clearweb     → https://ahmia.fi/search/?q={q}             [free, no key]
# blockchain.info    → https://blockchain.info/rawaddr/{addr}     [free, no key]
# Etherscan          → https://api.etherscan.io/api               [free key optional]
# Monero explorer    → https://xmrchain.net/api/transaction       [free, no key]

ABUSEIPDB_KEY    = os.getenv("ABUSEIPDB_KEY", "")      # optional: free account at abuseipdb.com
OTX_API_KEY      = os.getenv("OTX_API_KEY", "")         # optional: free account at otx.alienvault.com
ETHERSCAN_KEY    = os.getenv("ETHERSCAN_KEY", "")        # optional: free account at etherscan.io
URLSCAN_KEY      = os.getenv("URLSCAN_KEY", "")          # optional: free account at urlscan.io

# ── Scraping behaviour ────────────────────────────────────────────────────────
SCRAPE_TIMEOUT        = int(os.getenv("SCRAPE_TIMEOUT", "45"))
SCRAPE_MAX_CHARS      = int(os.getenv("SCRAPE_MAX_CHARS", "3000"))
SCRAPE_MAX_WORKERS    = int(os.getenv("SCRAPE_MAX_WORKERS", "5"))
SEARCH_MAX_WORKERS    = int(os.getenv("SEARCH_MAX_WORKERS", "8"))
FILTER_TOP_K          = int(os.getenv("FILTER_TOP_K", "20"))
