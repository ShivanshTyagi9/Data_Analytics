"""
entities.py
Extracts Indicators of Compromise (IOCs) and OSINT artefacts from raw text
using compiled regex patterns.  No external dependencies beyond stdlib + re.
"""
import re
from dataclasses import dataclass, field
from typing import List, Dict


# ── Compiled patterns ────────────────────────────────────────────────────────
_PAT = {
    "ipv4": re.compile(
        r"\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}"
        r"(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b"
    ),
    "ipv6": re.compile(
        r"\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b"
    ),
    "onion_v3": re.compile(
        r"\b[a-z2-7]{56}\.onion(?::\d{1,5})?\b", re.I
    ),
    "onion_v2": re.compile(
        r"\b[a-z2-7]{16}\.onion(?::\d{1,5})?\b", re.I
    ),
    "domain": re.compile(
        r"\b(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+"
        r"(?:com|net|org|io|gov|mil|edu|co|uk|de|ru|cn|fr|nl|se|no|"
        r"fi|pl|cz|hu|ro|bg|gr|pt|es|it|jp|kr|au|nz|br|za|info|biz|"
        r"xyz|online|site|store|tech|app|dev|cloud|ai|gg|me)\b"
    ),
    "email": re.compile(
        r"\b[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}\b"
    ),
    # MD5 / SHA1 / SHA256 hashes
    "md5":    re.compile(r"\b[0-9a-fA-F]{32}\b"),
    "sha1":   re.compile(r"\b[0-9a-fA-F]{40}\b"),
    "sha256": re.compile(r"\b[0-9a-fA-F]{64}\b"),
    # Crypto wallet addresses
    "btc": re.compile(
        r"\b(?:bc1[a-z0-9]{25,39}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})\b"
    ),
    "eth": re.compile(r"\b0x[a-fA-F0-9]{40}\b"),
    "xmr": re.compile(r"\b4[0-9AB][1-9A-HJ-NP-Za-km-z]{93}\b"),
    # CVEs
    "cve": re.compile(r"\bCVE-\d{4}-\d{4,7}\b", re.I),
    # PGP fingerprints  (8 hex groups of 4)
    "pgp": re.compile(r"\b(?:[0-9A-F]{4}\s?){10}\b", re.I),
    # Telegram handles / channels
    "telegram": re.compile(r"\bt\.me\/[a-zA-Z0-9_]{3,}\b"),
    # Phone numbers (rough international pattern)
    "phone": re.compile(r"\+\d{1,3}[\s\-]?\(?\d{1,4}\)?[\s\-]?\d{3,4}[\s\-]?\d{3,4}\b"),
}

# False-positive suppression: common non-IOC strings that match hash patterns
_HASH_IGNORE = {
    "00000000000000000000000000000000",
    "ffffffffffffffffffffffffffffffff",
}

# Private / loopback IP ranges to exclude
_PRIVATE_IP = re.compile(
    r"^(?:10\.|192\.168\.|172\.(?:1[6-9]|2\d|3[01])\.|127\.|0\.|255\.)"
)


@dataclass
class Entities:
    ipv4:     List[str] = field(default_factory=list)
    ipv6:     List[str] = field(default_factory=list)
    onions:   List[str] = field(default_factory=list)
    domains:  List[str] = field(default_factory=list)
    emails:   List[str] = field(default_factory=list)
    md5:      List[str] = field(default_factory=list)
    sha1:     List[str] = field(default_factory=list)
    sha256:   List[str] = field(default_factory=list)
    btc:      List[str] = field(default_factory=list)
    eth:      List[str] = field(default_factory=list)
    xmr:      List[str] = field(default_factory=list)
    cve:      List[str] = field(default_factory=list)
    pgp:      List[str] = field(default_factory=list)
    telegram: List[str] = field(default_factory=list)
    phones:   List[str] = field(default_factory=list)

    def total(self) -> int:
        return sum(len(getattr(self, f)) for f in self.__dataclass_fields__)

    def as_dict(self) -> Dict[str, List[str]]:
        return {k: v for k, v in self.__dict__.items() if v}


def _unique(lst: List[str]) -> List[str]:
    seen, out = set(), []
    for x in lst:
        lx = x.lower()
        if lx not in seen:
            seen.add(lx)
            out.append(x)
    return out


def extract(text: str) -> Entities:
    """Extract all IOC types from *text* and return a deduplicated Entities object."""
    e = Entities()

    # IPs — exclude private ranges
    e.ipv4 = _unique([ip for ip in _PAT["ipv4"].findall(text) if not _PRIVATE_IP.match(ip)])
    e.ipv6 = _unique(_PAT["ipv6"].findall(text))

    # Onion addresses (v3 first, then v2, deduplicated)
    onions_raw = _PAT["onion_v3"].findall(text) + _PAT["onion_v2"].findall(text)
    e.onions = _unique([o.lower() for o in onions_raw])

    # Regular domains — exclude those that are substrings of onions
    raw_domains = _PAT["domain"].findall(text)
    e.domains = _unique([
        d for d in raw_domains
        if not any(d in o for o in e.onions)
    ])

    e.emails   = _unique(_PAT["email"].findall(text))
    e.telegram = _unique(_PAT["telegram"].findall(text))
    e.phones   = _unique(_PAT["phone"].findall(text))
    e.cve      = _unique([c.upper() for c in _PAT["cve"].findall(text)])
    e.pgp      = _unique(_PAT["pgp"].findall(text))

    # Crypto wallets
    e.btc = _unique(_PAT["btc"].findall(text))
    e.eth = _unique(_PAT["eth"].findall(text))
    e.xmr = _unique(_PAT["xmr"].findall(text))

    # Hashes (filter obvious false positives)
    e.sha256 = _unique([h for h in _PAT["sha256"].findall(text) if h.lower() not in _HASH_IGNORE])
    # Remove sha256 matches before extracting shorter hashes to avoid overlap
    sha256_set = set(h.lower() for h in e.sha256)
    raw_sha1 = [h for h in _PAT["sha1"].findall(text)
                if h.lower() not in _HASH_IGNORE and not any(h.lower() in s for s in sha256_set)]
    e.sha1 = _unique(raw_sha1)
    raw_md5 = [h for h in _PAT["md5"].findall(text)
               if h.lower() not in _HASH_IGNORE
               and not any(h.lower() in s for s in sha256_set)
               and not any(h.lower() in s2 for s2 in set(h2.lower() for h2 in raw_sha1))]
    e.md5 = _unique(raw_md5)

    return e


def extract_from_scraped(scraped: dict) -> Entities:
    """Merge entities extracted from all scraped pages."""
    combined_text = " ".join(scraped.values())
    return extract(combined_text)
