"""
health.py
System health checks for Robin v2: Tor proxy, onion search engines, LLM connectivity.
"""

import time
import socket
import random
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, Any, List

from config import TOR_SOCKS_HOST, TOR_SOCKS_PORT, OPENAI_API_KEY, OPENAI_MODEL
from search import SEARCH_ENGINES, USER_AGENTS, _tor_session


def check_tor_proxy() -> Dict[str, Any]:
    """Verify that the Tor SOCKS5 proxy is accepting TCP connections."""
    try:
        start = time.time()
        sock  = socket.create_connection((TOR_SOCKS_HOST, TOR_SOCKS_PORT), timeout=5)
        sock.close()
        return {
            "status":     "up",
            "latency_ms": round((time.time() - start) * 1000),
            "error":      None,
        }
    except Exception as e:
        return {"status": "down", "latency_ms": None, "error": str(e)}


def check_tor_ip() -> Dict[str, Any]:
    """
    Verify Tor is routing traffic by checking the exit-node IP via check.torproject.org.
    """
    try:
        session = _tor_session()
        start   = time.time()
        r       = session.get("https://check.torproject.org/api/ip", timeout=20)
        data    = r.json()
        return {
            "status":     "up" if data.get("IsTor") else "no_tor",
            "exit_ip":    data.get("IP"),
            "is_tor":     data.get("IsTor", False),
            "latency_ms": round((time.time() - start) * 1000),
            "error":      None,
        }
    except Exception as e:
        return {"status": "down", "exit_ip": None, "is_tor": False, "latency_ms": None, "error": str(e)}


def check_llm_health(model_id: str) -> Dict[str, Any]:
    """Send a minimal prompt to verify OpenAI connectivity."""
    if not OPENAI_API_KEY:
        return {"status": "no_key", "latency_ms": None, "error": "OPENAI_API_KEY not set", "model": model_id}
    try:
        from llm_utils import build_llm
        llm   = build_llm(model_id, streaming=False)
        start = time.time()
        resp  = llm.invoke("Reply with just: OK")
        latency = round((time.time() - start) * 1000)
        text  = getattr(resp, "content", str(resp)).strip()
        return {
            "status":     "up" if text else "empty",
            "latency_ms": latency,
            "model":      model_id,
            "response":   text[:40],
            "error":      None,
        }
    except Exception as e:
        return {"status": "down", "latency_ms": None, "model": model_id, "error": str(e)[:200]}


def _ping_engine(engine: Dict[str, str]) -> Dict[str, Any]:
    name = engine["name"]
    url  = engine["url"].format(query="test")
    try:
        session = _tor_session()
        headers = {"User-Agent": random.choice(USER_AGENTS)}
        start   = time.time()
        resp    = session.get(url, headers=headers, timeout=20)
        latency = round((time.time() - start) * 1000)
        ok      = resp.status_code == 200
        return {
            "name":       name,
            "status":     "up" if ok else "down",
            "latency_ms": latency,
            "error":      None if ok else f"HTTP {resp.status_code}",
        }
    except Exception as e:
        return {"name": name, "status": "down", "latency_ms": None, "error": str(e)[:80]}


def check_search_engines(max_workers: int = 8) -> List[Dict[str, Any]]:
    """Concurrently ping all onion search engines via Tor."""
    results = []
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futs = {ex.submit(_ping_engine, eng): eng for eng in SEARCH_ENGINES}
        for fut in as_completed(futs):
            results.append(fut.result())
    name_order = {e["name"]: i for i, e in enumerate(SEARCH_ENGINES)}
    results.sort(key=lambda r: name_order.get(r["name"], 999))
    return results
