"""
llm.py
All LLM-powered steps for Robin v2.
Provider: OpenAI only (ChatGPT / GPT-4o family).

Steps:
  1. refine_query        — turn user input into a precise dark-web search query
  2. filter_results      — select top-K relevant results from raw search list
  3. score_content       — give each scraped page a relevance score 0-10
  4. generate_summary    — produce a structured threat intelligence report
  5. extract_entities_ai — AI-assisted entity extraction (supplements regex)
"""

import re
import json
import logging
import warnings

warnings.filterwarnings("ignore")

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

from llm_utils import build_llm, BufferedStreamingHandler
from typing import Callable, Dict, List, Optional

logger = logging.getLogger("robin.llm")


# ═══════════════════════════════════════════════════════════════════════════════
# PRESET SYSTEM PROMPTS
# ═══════════════════════════════════════════════════════════════════════════════

PRESET_PROMPTS: Dict[str, str] = {

    "threat_intel": """
You are a senior Cyber Threat Intelligence (CTI) analyst with deep expertise in dark-web OSINT.
You receive raw scraped content from onion sites and must produce a precise, evidence-based
technical intelligence report.

Rules:
1. Cite source URLs inline using [URL] notation.
2. Extract and list all technical artefacts (IPs, domains, onion URLs, emails, wallets, CVEs, hashes, malware names, TTPs, threat actor aliases).
3. Map tactics to MITRE ATT&CK framework where applicable.
4. Assess the credibility of each source (reliable / unverified / suspected honeypot).
5. Generate 3-6 specific, data-driven key insights.
6. Suggest 3-5 concrete next investigative steps.
7. Ignore NSFW / off-topic content; flag if most content is irrelevant.
8. Be precise. Do not speculate beyond the evidence.

Output format (strict Markdown):

## Query
{query}

## Executive Summary
(2-3 sentences)

## Sources Analysed
| URL | Title | Credibility |
|-----|-------|-------------|

## Intelligence Artefacts
### Network Indicators
### Cryptocurrency
### Malware / Tools
### Threat Actors
### Credentials / PII

## MITRE ATT&CK Mapping
(if applicable)

## Key Insights
1. ...
2. ...

## Risk Assessment
**Overall Risk Level:** LOW / MEDIUM / HIGH / CRITICAL
(justification)

## Recommended Next Steps
1. ...
""",

    "ransomware_malware": """
You are a Malware and Ransomware Intelligence Expert specialising in dark-web threat tracking.

Rules:
1. Focus on ransomware groups, malware families, RaaS affiliates, exploit kits, loaders, stealers.
2. Identify C2 infrastructure: domains, IPs, onion addresses, port/protocol.
3. Map TTPs to MITRE ATT&CK (especially TA0001–TA0010).
4. Identify victim organisations, sectors, geographies if mentioned.
5. Note double/triple extortion indicators and data-leak blog activity.
6. Generate 3-5 malware-focused key insights.

Output format (strict Markdown):

## Query
{query}

## Executive Summary

## Sources Analysed
| URL | Title | Credibility |

## Malware / Ransomware Indicators
### File Hashes
### C2 Infrastructure
### Payload Names & Variants

## Ransomware Group Profile
- **Name / Alias:**
- **Known Victims:**
- **Sector Targeting:**
- **Data Leak Site:**

## MITRE ATT&CK Mapping

## Key Insights

## Detection & Hunting Rules
(YARA / Sigma snippets if applicable)

## Recommended Next Steps
""",

    "personal_identity": """
You are a Personal Threat Intelligence Expert specialising in identity-theft and PII exposure on dark-web markets and breach dumps.

Rules:
1. Focus on PII: names, emails, phones, addresses, SSNs, passport/NIN data, DOBs, financial accounts.
2. Identify breach sources, data brokers, carding shops, and identity marketplaces.
3. Assess exposure severity: Critical (live financials) / High (full identity pack) / Medium (email+pw) / Low (email only).
4. Never reproduce or display full PII values — redact after first 3 characters (e.g. "joh*****@gmail.com").
5. Generate 3-5 risk-focused insights.

Output format (strict Markdown):

## Query
{query}

## Executive Summary

## Sources Analysed
| URL | Title | Credibility |

## Exposed PII Artefacts
| Type | Redacted Value | Source Context | Severity |
|------|----------------|----------------|----------|

## Breach / Marketplace Sources

## Exposure Risk Assessment
**Risk Level:**

## Key Insights

## Protective Actions
1. ...
""",

    "corporate_espionage": """
You are a Corporate Intelligence Expert specialising in dark-web data leaks, insider threats, and corporate espionage.

Rules:
1. Focus on leaked credentials, source code, internal documents, financial records, API keys, employee/customer databases.
2. Identify the likely exfiltration vector (insider / external breach / supply-chain) where evidence supports it.
3. Assess business impact: operational, reputational, legal/regulatory.
4. Flag any Incident Response urgency indicators (active sale, auction deadline, etc.).
5. Generate 3-5 business-risk insights.

Output format (strict Markdown):

## Query
{query}

## Executive Summary

## Sources Analysed
| URL | Title | Credibility |

## Leaked Corporate Artefacts
### Credentials & Access
### Source Code / IP
### Internal Documents
### Customer / Employee Data

## Threat Actor / Broker Activity

## Business Impact Assessment
**Impact Level:**
- Operational:
- Reputational:
- Legal/Regulatory:

## Key Insights

## Incident Response Actions
1. ...

## Recommended Next Steps
""",
}


# ═══════════════════════════════════════════════════════════════════════════════
# PIPELINE FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def get_llm(model_id: str, ui_callback: Optional[Callable] = None):
    """Convenience wrapper used by ui.py."""
    return build_llm(model_id, streaming=True, ui_callback=ui_callback)


def refine_query(llm, user_input: str) -> str:
    """
    Converts a free-text user query into a short, optimised dark-web search string.
    """
    system = """You are a Cybercrime Threat Intelligence Expert.

Task: Refine the user's query for dark-web search engines.

Rules:
1. Keep it to 5 words or fewer.
2. Use the most specific threat-relevant keywords.
3. No Boolean operators (AND / OR / NOT).
4. Output ONLY the refined query string — no explanation, no quotes.

Examples:
  "find ransomware groups targeting hospitals" → "healthcare ransomware group 2024"
  "leaked credit cards for sale"              → "credit card dump sale"
  "APT group using zero day"                  → "APT zero-day exploit"
"""
    prompt = ChatPromptTemplate([("system", system), ("user", "{query}")])
    chain  = prompt | llm | StrOutputParser()
    return chain.invoke({"query": user_input}).strip()


def filter_results(llm, query: str, results: List[Dict]) -> List[Dict]:
    """
    Ask the LLM to select the top-20 most relevant results from the raw list.
    Falls back to first-20 if parsing fails.
    """
    if not results:
        return []

    system = """You are a Cybercrime Threat Intelligence Expert.

Given a dark-web search query and a numbered list of result links+titles,
output ONLY a comma-separated list of the indices (1-based) of the top 20 most
relevant results. Output nothing else — no explanations, no extra text.

Example output: 3,7,12,15,2,9

Search Query: {query}
"""
    # Build result list string
    lines = []
    for i, r in enumerate(results, 1):
        link  = re.sub(r"(?<=\.onion).*", "", r.get("link", ""))
        title = re.sub(r"[^0-9a-zA-Z\-\. ]", " ", r.get("title", ""))[:60]
        lines.append(f"{i}. {link} — {title}")
    result_str = "\n".join(lines)

    prompt = ChatPromptTemplate([("system", system), ("user", "{results}")])
    chain  = prompt | llm | StrOutputParser()
    try:
        raw = chain.invoke({"query": query, "results": result_str})
    except Exception as e:
        logger.warning("filter_results LLM call failed: %s", e)
        return results[:20]

    indices = []
    for tok in re.findall(r"\d+", raw):
        idx = int(tok)
        if 1 <= idx <= len(results) and idx not in indices:
            indices.append(idx)

    if not indices:
        logger.warning("filter_results could not parse '%s', defaulting to first 20", raw)
        indices = list(range(1, min(len(results), 20) + 1))

    return [results[i - 1] for i in indices[:20]]


def score_content(llm, query: str, scraped: Dict[str, str]) -> Dict[str, int]:
    """
    Ask the LLM to score each scraped page 0-10 for relevance.
    Returns {url: score}.
    """
    if not scraped:
        return {}

    lines = []
    url_index: Dict[int, str] = {}
    for i, (url, text) in enumerate(scraped.items(), 1):
        snippet = text[:300].replace("\n", " ")
        lines.append(f"{i}. [{url}] {snippet}")
        url_index[i] = url

    system = """You are a Cybercrime Threat Intelligence Expert.

Rate each scraped page for relevance to the query on a scale 0-10.
Output ONLY a JSON object: {"1": score, "2": score, ...} — no other text.

Query: {query}
"""
    prompt = ChatPromptTemplate([("system", system), ("user", "{pages}")])
    chain  = prompt | llm | StrOutputParser()
    try:
        raw   = chain.invoke({"query": query, "pages": "\n".join(lines)})
        clean = re.sub(r"```(?:json)?|```", "", raw).strip()
        data  = json.loads(clean)
        return {url_index[int(k)]: int(v) for k, v in data.items() if int(k) in url_index}
    except Exception as e:
        logger.warning("score_content failed: %s", e)
        return {}


def generate_summary(
    llm,
    query: str,
    scraped: Dict[str, str],
    preset: str = "threat_intel",
    custom_instructions: str = "",
) -> str:
    """
    Generate a structured threat intelligence report from scraped content.
    Uses streaming via the LLM's attached callbacks.
    """
    system_prompt = PRESET_PROMPTS.get(preset, PRESET_PROMPTS["threat_intel"])
    if custom_instructions.strip():
        system_prompt += f"\n\nAdditionally: {custom_instructions.strip()}"

    # Concatenate scraped content with URL headers for citation
    content_parts = []
    for url, text in scraped.items():
        content_parts.append(f"--- SOURCE: {url} ---\n{text[:2500]}\n")
    content = "\n".join(content_parts)

    prompt = ChatPromptTemplate([("system", system_prompt), ("user", "{content}")])
    chain  = prompt | llm | StrOutputParser()
    return chain.invoke({"query": query, "content": content})
