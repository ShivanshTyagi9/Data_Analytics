"""
llm_utils.py
OpenAI-only LLM utilities for Robin v2.
Supports gpt-4o, gpt-4o-mini, and any OpenAI-compatible model.
"""

from typing import Callable, Optional, List
from langchain_openai import ChatOpenAI
from langchain_core.callbacks.base import BaseCallbackHandler

from config import OPENAI_API_KEY, OPENAI_BASE_URL, OPENAI_MODEL


# ── Streaming handler ─────────────────────────────────────────────────────────

class BufferedStreamingHandler(BaseCallbackHandler):
    """
    Buffers LLM token stream and flushes to a UI callback on newline or
    every *buffer_limit* characters, whichever comes first.
    """
    def __init__(
        self,
        buffer_limit: int = 60,
        ui_callback: Optional[Callable[[str], None]] = None,
    ):
        self.buffer       = ""
        self.buffer_limit = buffer_limit
        self.ui_callback  = ui_callback

    def on_llm_new_token(self, token: str, **kwargs) -> None:
        self.buffer += token
        if "\n" in token or len(self.buffer) >= self.buffer_limit:
            self._flush()

    def on_llm_end(self, response, **kwargs) -> None:
        self._flush()

    def _flush(self) -> None:
        if self.buffer:
            if self.ui_callback:
                self.ui_callback(self.buffer)
            self.buffer = ""


# ── Available models ─────────────────────────────────────────────────────────

AVAILABLE_MODELS = {
    "gpt-4o-mini":       {"label": "GPT-4o Mini  (fast · cheap)",   "context_k": 128},
    "gpt-4o":            {"label": "GPT-4o       (smart · balanced)", "context_k": 128},
    "gpt-4.1-mini":      {"label": "GPT-4.1 Mini (latest mini)",     "context_k": 128},
    "gpt-4.1":           {"label": "GPT-4.1      (latest full)",      "context_k": 128},
    "o4-mini":           {"label": "o4-mini      (reasoning)",        "context_k": 128},
}


def get_model_choices() -> List[str]:
    """Return list of model identifiers that have a valid API key configured."""
    if not OPENAI_API_KEY:
        return []
    return list(AVAILABLE_MODELS.keys())


def get_model_label(model_id: str) -> str:
    return AVAILABLE_MODELS.get(model_id, {}).get("label", model_id)


# ── LLM factory ──────────────────────────────────────────────────────────────

def build_llm(
    model_id: str,
    streaming: bool = True,
    ui_callback: Optional[Callable[[str], None]] = None,
    temperature: float = 0.0,
) -> ChatOpenAI:
    """
    Build and return a ChatOpenAI instance, optionally with a streaming callback.
    """
    if not OPENAI_API_KEY:
        raise ValueError(
            "OPENAI_API_KEY is not set. Add it to your .env file.\n"
            "Get a key at https://platform.openai.com/api-keys"
        )
    callbacks = []
    if streaming and ui_callback:
        callbacks = [BufferedStreamingHandler(buffer_limit=60, ui_callback=ui_callback)]

    return ChatOpenAI(
        model_name=model_id,
        openai_api_key=OPENAI_API_KEY,
        openai_api_base=OPENAI_BASE_URL,
        temperature=temperature,
        streaming=streaming,
        callbacks=callbacks if callbacks else None,
        max_retries=3,
    )
