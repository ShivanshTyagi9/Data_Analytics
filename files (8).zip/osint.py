"""
osint.py
Free OSINT enrichment module.
Every source here is either completely free (no key) or uses an optional
free-tier key.  No paid plans required.

Sources used:
  • Shodan InternetDB   — open ports / CVEs / tags for any IP (no key, free forever)
  • ip-api.com          — IP geolocation / ASN (no key, 45 req/min)
  • AbuseIPDB           — IP abuse reputation (optional free key, 1k checks/day)
  • AlienVault OTX      — threat pulses (optional free key, high rate limit)
  • urlscan.io          — URL/domain scan history (no key needed for search)
  • psbdmp.ws           — Pastebin dump index (no key)
  • Ahmia.fi            — Clearweb Tor search index (no key, fallback when Tor is down)
  • Blockchain.info     — Bitcoin address history (no key)
  • Etherscan           — ETH address summary (optional free key)
"""

import time
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional

from config import (
    ABUSEIPDB_KEY,
    OTX_API_KEY,
    ETHERSCAN_KEY,
    URLSCAN_KEY,
)

_SESSION = requests.Session()
_SESSION.headers.update({"User-Agent": "Robin-OSINT/2.0 (research; contact: osint@example.com)"})

_TIMEOUT = 12


def _get(url: str, headers: Optional[Dict] = None, params: Optional[Dict] = None) -> Optional[Dict]:
    try:
        r = _SESSION.get(url, headers=headers or {}, params=params or {}, timeout=_TIMEOUT)
        if r.status_code == 200:
            return r.json()
    except Exception:
        pass
    return None


# ── IP Enrichment ────────────────────────────────────────────────────────────

def enrich_ip_shodan(ip: str) -> Dict[str, Any]:
    """
    Shodan InternetDB — free, no API key, returns ports / vulns / tags.
    https://internetdb.shodan.io/{ip}
    """
    data = _get(f"https://internetdb.shodan.io/{ip}")
    if not data:
        return {}
    return {
        "source": "Shodan InternetDB",
        "ports":  data.get("ports", []),
        "cpes":   data.get("cpes", []),
        "vulns":  data.get("vulns", []),
        "tags":   data.get("tags", []),
        "hostnames": data.get("hostnames", []),
    }


def enrich_ip_geo(ip: str) -> Dict[str, Any]:
    """
    ip-api.com — free geolocation + ASN (no key, 45 req/min).
    """
    data = _get(
        f"http://ip-api.com/json/{ip}",
        params={"fields": "status,country,regionName,city,isp,org,as,lat,lon,reverse,mobile,proxy,hosting"}
    )
    if not data or data.get("status") != "success":
        return {}
    return {
        "source":  "ip-api.com",
        "country": data.get("country"),
        "region":  data.get("regionName"),
        "city":    data.get("city"),
        "isp":     data.get("isp"),
        "org":     data.get("org"),
        "asn":     data.get("as"),
        "is_proxy":   data.get("proxy", False),
        "is_hosting": data.get("hosting", False),
        "lat": data.get("lat"),
        "lon": data.get("lon"),
    }


def enrich_ip_abuseipdb(ip: str) -> Dict[str, Any]:
    """AbuseIPDB — free key (1000 checks/day). Skip if no key."""
    if not ABUSEIPDB_KEY:
        return {}
    data = _get(
        "https://api.abuseipdb.com/api/v2/check",
        headers={"Key": ABUSEIPDB_KEY, "Accept": "application/json"},
        params={"ipAddress": ip, "maxAgeInDays": 90, "verbose": ""}
    )
    if not data:
        return {}
    d = data.get("data", {})
    return {
        "source":            "AbuseIPDB",
        "abuse_score":       d.get("abuseConfidenceScore"),
        "total_reports":     d.get("totalReports"),
        "last_reported":     d.get("lastReportedAt"),
        "usage_type":        d.get("usageType"),
        "isp":               d.get("isp"),
        "is_tor":            d.get("isTor", False),
    }


def enrich_ip(ip: str) -> Dict[str, Any]:
    """Run all free IP enrichment sources concurrently."""
    enrichers = [enrich_ip_shodan, enrich_ip_geo, enrich_ip_abuseipdb]
    results: Dict[str, Any] = {"ip": ip}
    with ThreadPoolExecutor(max_workers=3) as ex:
        futs = {ex.submit(fn, ip): fn.__name__ for fn in enrichers}
        for fut in as_completed(futs):
            try:
                results.update(fut.result())
            except Exception:
                pass
    return results


# ── Domain Enrichment ────────────────────────────────────────────────────────

def enrich_domain_urlscan(domain: str) -> Dict[str, Any]:
    """
    urlscan.io — search for recent scans of a domain (no key needed for search).
    """
    headers = {}
    if URLSCAN_KEY:
        headers["API-Key"] = URLSCAN_KEY
    data = _get(
        "https://urlscan.io/api/v1/search/",
        headers=headers,
        params={"q": f"domain:{domain}", "size": 5}
    )
    if not data:
        return {}
    results = data.get("results", [])[:5]
    return {
        "source": "urlscan.io",
        "total_scans": data.get("total", 0),
        "recent_scans": [
            {
                "url":         r.get("page", {}).get("url"),
                "ip":          r.get("page", {}).get("ip"),
                "country":     r.get("page", {}).get("country"),
                "verdict":     r.get("verdicts", {}).get("overall", {}).get("score", 0),
                "malicious":   r.get("verdicts", {}).get("overall", {}).get("malicious", False),
                "scanned_at":  r.get("task", {}).get("time"),
            }
            for r in results
        ],
    }


def enrich_domain_otx(domain: str) -> Dict[str, Any]:
    """
    AlienVault OTX — threat pulses for a domain (free, optional key for higher limits).
    """
    headers = {}
    if OTX_API_KEY:
        headers["X-OTX-API-KEY"] = OTX_API_KEY
    data = _get(f"https://otx.alienvault.com/api/v1/indicators/domain/{domain}/general", headers=headers)
    if not data:
        return {}
    return {
        "source":        "AlienVault OTX",
        "pulse_count":   data.get("pulse_info", {}).get("count", 0),
        "malware_families": [
            m.get("display_name")
            for m in data.get("pulse_info", {}).get("related", {}).get("malware_families", [])
        ][:5],
        "reputation":    data.get("reputation", 0),
        "country":       data.get("country_name"),
    }


# ── Cryptocurrency Enrichment ─────────────────────────────────────────────────

def enrich_btc(address: str) -> Dict[str, Any]:
    """Blockchain.info — free, no key."""
    data = _get(f"https://blockchain.info/rawaddr/{address}?limit=5")
    if not data:
        return {}
    return {
        "source":           "Blockchain.info",
        "balance_btc":      data.get("final_balance", 0) / 1e8,
        "total_received_btc": data.get("total_received", 0) / 1e8,
        "tx_count":         data.get("n_tx", 0),
        "recent_txs": [
            {
                "hash":   tx.get("hash"),
                "time":   tx.get("time"),
                "result": tx.get("result", 0) / 1e8,
            }
            for tx in data.get("txs", [])[:3]
        ],
    }


def enrich_eth(address: str) -> Dict[str, Any]:
    """Etherscan — free (higher limits with free API key)."""
    params = {
        "module": "account",
        "action": "balance",
        "address": address,
        "tag": "latest",
    }
    if ETHERSCAN_KEY:
        params["apikey"] = ETHERSCAN_KEY
    data = _get("https://api.etherscan.io/api", params=params)
    if not data or data.get("status") != "1":
        return {}
    balance_eth = int(data.get("result", 0)) / 1e18
    return {
        "source":      "Etherscan",
        "balance_eth": round(balance_eth, 6),
        "address":     address,
        "explorer_url": f"https://etherscan.io/address/{address}",
    }


# ── OTX Threat Pulse Search ───────────────────────────────────────────────────

def search_otx_pulses(query: str, limit: int = 10) -> List[Dict[str, Any]]:
    """
    Search AlienVault OTX for threat pulses matching *query*.
    Free public endpoint; optional key for higher rate limits.
    """
    headers = {}
    if OTX_API_KEY:
        headers["X-OTX-API-KEY"] = OTX_API_KEY
    data = _get(
        "https://otx.alienvault.com/api/v1/search/pulses",
        headers=headers,
        params={"q": query, "limit": limit}
    )
    if not data:
        return []
    return [
        {
            "id":               p.get("id"),
            "name":             p.get("name"),
            "author":           p.get("author_name"),
            "tlp":              p.get("tlp", "white"),
            "indicator_count":  p.get("indicator_count", 0),
            "adversary":        p.get("adversary", ""),
            "malware_families": p.get("malware_families", []),
            "tags":             p.get("tags", [])[:5],
            "created":          p.get("created"),
            "url":              f"https://otx.alienvault.com/pulse/{p.get('id')}",
        }
        for p in data.get("results", [])[:limit]
    ]


# ── Paste Site Search ─────────────────────────────────────────────────────────

def search_pastes(query: str) -> List[Dict[str, Any]]:
    """psbdmp.ws — free Pastebin dump search (no key)."""
    data = _get(f"https://psbdmp.ws/api/v3/search/{requests.utils.quote(query)}")
    if not data:
        return []
    return [
        {
            "id":    p.get("id"),
            "snippet": (p.get("text") or "")[:120],
            "date":  p.get("time"),
            "url":   f"https://pastebin.com/{p.get('id')}",
        }
        for p in (data.get("data") or [])[:10]
    ]


# ── Ahmia clearweb fallback ───────────────────────────────────────────────────

def search_ahmia_clearweb(query: str) -> List[Dict[str, Any]]:
    """
    Ahmia.fi — clearweb-accessible Tor search index.
    Useful as a fallback when the local Tor proxy is unavailable.
    """
    try:
        r = requests.get(
            "https://ahmia.fi/search/",
            params={"q": query},
            timeout=15,
            headers={"User-Agent": "Robin-OSINT/2.0"},
        )
        if r.status_code != 200:
            return []
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(r.text, "html.parser")
        results = []
        for li in soup.select("li.result")[:20]:
            a = li.find("a")
            if not a:
                continue
            href  = a.get("href", "")
            title = a.get_text(strip=True)
            desc_el = li.find("p")
            desc = desc_el.get_text(strip=True) if desc_el else ""
            if ".onion" in href:
                results.append({"title": title, "link": href, "snippet": desc[:200]})
        return results
    except Exception:
        return []


# ── Bulk enrichment helper ────────────────────────────────────────────────────

def bulk_enrich_entities(entities) -> Dict[str, Any]:
    """
    Given an Entities dataclass, run all relevant free enrichment calls
    concurrently and return a structured dict.
    """
    enriched: Dict[str, Any] = {
        "ips":     [],
        "domains": [],
        "btc":     [],
        "eth":     [],
        "otx_pulses": [],
        "pastes":  [],
    }

    tasks = []
    with ThreadPoolExecutor(max_workers=10) as ex:
        # IPs (cap at 5 to stay within rate limits)
        for ip in entities.ipv4[:5]:
            tasks.append(("ip", ex.submit(enrich_ip, ip)))

        # Domains (cap at 5)
        for dom in entities.domains[:5]:
            tasks.append(("domain_urlscan", ex.submit(enrich_domain_urlscan, dom)))
            tasks.append(("domain_otx",     ex.submit(enrich_domain_otx, dom)))

        # Crypto (cap at 3 each)
        for addr in entities.btc[:3]:
            tasks.append(("btc", ex.submit(enrich_btc, addr)))
        for addr in entities.eth[:3]:
            tasks.append(("eth", ex.submit(enrich_eth, addr)))

        for label, fut in tasks:
            try:
                result = fut.result()
                if result:
                    if label == "ip":
                        enriched["ips"].append(result)
                    elif label.startswith("domain"):
                        enriched["domains"].append(result)
                    elif label == "btc":
                        enriched["btc"].append(result)
                    elif label == "eth":
                        enriched["eth"].append(result)
            except Exception:
                pass

    return enriched
