"""
report.py
Professional HTML + Markdown report generator for Robin v2.
"""

import re
import json
from datetime import datetime
from typing import Dict, Any, List, Optional


def _now() -> str:
    return datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")


def _risk_color(text: str) -> str:
    t = text.upper()
    if "CRITICAL" in t: return "#ff3b5c"
    if "HIGH"     in t: return "#ff8c00"
    if "MEDIUM"   in t: return "#ffd700"
    return "#00e676"


def _entity_rows(entities) -> str:
    if entities is None:
        return ""
    rows = []
    FIELDS = [
        ("IPv4 Addresses",      "ipv4",    "#4fc3f7"),
        ("Onion Addresses",     "onions",  "#ce93d8"),
        ("Domains",             "domains", "#80cbc4"),
        ("Email Addresses",     "emails",  "#ffcc02"),
        ("Bitcoin (BTC)",       "btc",     "#f7931a"),
        ("Ethereum (ETH)",      "eth",     "#627eea"),
        ("Monero (XMR)",        "xmr",     "#ff6600"),
        ("CVEs",                "cve",     "#ff5252"),
        ("SHA-256 Hashes",      "sha256",  "#b0bec5"),
        ("SHA-1 Hashes",        "sha1",    "#b0bec5"),
        ("MD5 Hashes",          "md5",     "#b0bec5"),
        ("Telegram Handles",    "telegram","#2ca5e0"),
        ("Phone Numbers",       "phones",  "#aed581"),
    ]
    for label, attr, color in FIELDS:
        vals = getattr(entities, attr, [])
        if vals:
            items = "".join(
                f'<code style="background:#1e2a3a;padding:2px 6px;border-radius:3px;'
                f'margin:2px;display:inline-block;font-size:11px;color:{color}">{v}</code>'
                for v in vals[:30]
            )
            rows.append(f"""
            <tr>
              <td style="padding:8px 12px;color:#90a4ae;font-size:12px;white-space:nowrap;
                         vertical-align:top;border-bottom:1px solid #1a2535">{label}
                <span style="background:{color}22;color:{color};border-radius:10px;
                             padding:1px 7px;font-size:10px;margin-left:6px">{len(vals)}</span>
              </td>
              <td style="padding:8px 12px;border-bottom:1px solid #1a2535">{items}</td>
            </tr>""")
    return "".join(rows)


def generate_html_report(
    query: str,
    summary_md: str,
    entities=None,
    enrichment: Optional[Dict] = None,
    otx_pulses: Optional[List] = None,
    pastes: Optional[List] = None,
    search_count: int = 0,
    filtered_count: int = 0,
    scraped_count: int = 0,
) -> str:
    ts = _now()
    entity_table = _entity_rows(entities)

    # Convert summary markdown to basic HTML
    html_summary = re.sub(r"^## (.+)$",
        r'<h3 style="color:#4fc3f7;margin-top:20px;margin-bottom:6px;font-size:14px;'
        r'letter-spacing:1px;text-transform:uppercase">\1</h3>', summary_md, flags=re.M)
    html_summary = re.sub(r"^### (.+)$",
        r'<h4 style="color:#80cbc4;margin-top:14px;font-size:13px">\1</h4>',
        html_summary, flags=re.M)
    html_summary = re.sub(r"\*\*(.+?)\*\*", r'<strong style="color:#e0e0e0">\1</strong>', html_summary)
    html_summary = re.sub(r"`(.+?)`", r'<code style="background:#1a2535;padding:1px 5px;border-radius:3px;font-size:11px;color:#80cbc4">\1</code>', html_summary)
    html_summary = html_summary.replace("\n", "<br>")

    # OTX pulse rows
    otx_rows = ""
    for p in (otx_pulses or [])[:10]:
        otx_rows += f"""
        <tr style="border-bottom:1px solid #1a2535">
          <td style="padding:8px 12px;font-size:12px">
            <a href="{p.get('url','#')}" style="color:#4fc3f7;text-decoration:none">{p.get('name','')[:60]}</a>
          </td>
          <td style="padding:8px 12px;font-size:11px;color:#90a4ae">{p.get('author','')}</td>
          <td style="padding:8px 12px;font-size:11px;color:#ffcc02">{p.get('indicator_count',0)}</td>
          <td style="padding:8px 12px;font-size:11px;color:#ce93d8">{p.get('tlp','').upper()}</td>
        </tr>"""

    # Paste rows
    paste_rows = ""
    for p in (pastes or [])[:8]:
        paste_rows += f"""
        <tr style="border-bottom:1px solid #1a2535">
          <td style="padding:8px 12px;font-size:11px;color:#90a4ae;font-family:monospace">{p.get('id','')}</td>
          <td style="padding:8px 12px;font-size:12px;color:#cfd8dc">{p.get('snippet','')[:100]}</td>
          <td style="padding:8px 12px;font-size:11px">
            <a href="{p.get('url','#')}" style="color:#4fc3f7">View</a>
          </td>
        </tr>"""

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Robin OSINT Report — {query}</title>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ background: #0a1628; color: #cfd8dc; font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px; line-height: 1.7; }}
  .page {{ max-width: 1100px; margin: 0 auto; padding: 40px 32px; }}
  .header {{ border-bottom: 2px solid #1a2535; padding-bottom: 24px; margin-bottom: 32px; display:flex; justify-content:space-between; align-items:flex-start; }}
  .logo {{ font-size: 28px; font-weight: 700; color: #4fc3f7; letter-spacing: 3px; }}
  .logo span {{ color: #00e676; }}
  .meta {{ text-align: right; color: #546e7a; font-size: 11px; line-height: 2; }}
  .section {{ margin-bottom: 36px; }}
  .section-title {{ font-size: 11px; letter-spacing: 2px; text-transform: uppercase; color: #546e7a; border-left: 3px solid #4fc3f7; padding-left: 10px; margin-bottom: 16px; }}
  .card {{ background: #0f1f35; border: 1px solid #1a2535; border-radius: 8px; padding: 20px; margin-bottom: 16px; }}
  .stat-grid {{ display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; }}
  .stat {{ background: #0f1f35; border: 1px solid #1a2535; border-radius: 8px; padding: 16px; text-align: center; }}
  .stat-num {{ font-size: 32px; font-weight: 700; color: #00e676; }}
  .stat-lbl {{ font-size: 11px; color: #546e7a; margin-top: 4px; letter-spacing: 1px; }}
  table {{ width: 100%; border-collapse: collapse; }}
  th {{ text-align: left; padding: 8px 12px; font-size: 10px; letter-spacing: 1px; color: #546e7a; border-bottom: 1px solid #1a2535; text-transform: uppercase; }}
  .query-box {{ background: #0f1f35; border: 1px solid #4fc3f7; border-radius: 6px; padding: 12px 16px; font-family: monospace; font-size: 14px; color: #4fc3f7; }}
  .footer {{ border-top: 1px solid #1a2535; padding-top: 20px; color: #37474f; font-size: 11px; text-align: center; }}
  @media print {{ body {{ background: white; color: black; }} }}
</style>
</head>
<body>
<div class="page">

  <div class="header">
    <div>
      <div class="logo">ROBIN<span>.</span>OSINT</div>
      <div style="color:#546e7a;font-size:11px;margin-top:6px;letter-spacing:1px">AI-POWERED DARK WEB INTELLIGENCE PLATFORM</div>
    </div>
    <div class="meta">
      <div>Generated: {ts}</div>
      <div>Classification: TLP:WHITE</div>
      <div>Report Engine: Robin v2.0</div>
    </div>
  </div>

  <div class="section">
    <div class="section-title">Intelligence Query</div>
    <div class="query-box">{query}</div>
  </div>

  <div class="section">
    <div class="section-title">Pipeline Statistics</div>
    <div class="stat-grid">
      <div class="stat"><div class="stat-num">{search_count}</div><div class="stat-lbl">Raw Results</div></div>
      <div class="stat"><div class="stat-num">{filtered_count}</div><div class="stat-lbl">Filtered</div></div>
      <div class="stat"><div class="stat-num">{scraped_count}</div><div class="stat-lbl">Pages Scraped</div></div>
    </div>
  </div>

  <div class="section">
    <div class="section-title">AI Intelligence Report</div>
    <div class="card" style="line-height:1.9">{html_summary}</div>
  </div>

  {"" if not entity_table else f'''
  <div class="section">
    <div class="section-title">Extracted IOCs &amp; Artefacts</div>
    <div class="card" style="padding:0;overflow:hidden">
      <table><tbody>{entity_table}</tbody></table>
    </div>
  </div>'''}

  {"" if not otx_rows else f'''
  <div class="section">
    <div class="section-title">AlienVault OTX Threat Pulses</div>
    <div class="card" style="padding:0;overflow:hidden">
      <table>
        <thead><tr>
          <th>Pulse</th><th>Author</th><th>Indicators</th><th>TLP</th>
        </tr></thead>
        <tbody>{otx_rows}</tbody>
      </table>
    </div>
  </div>'''}

  {"" if not paste_rows else f'''
  <div class="section">
    <div class="section-title">Paste Site Hits</div>
    <div class="card" style="padding:0;overflow:hidden">
      <table>
        <thead><tr><th>ID</th><th>Snippet</th><th>Link</th></tr></thead>
        <tbody>{paste_rows}</tbody>
      </table>
    </div>
  </div>'''}

  <div class="footer">
    Robin OSINT v2 · {ts} · Queries routed via Tor · All data from public sources ·
    For authorised research use only.
  </div>

</div>
</body>
</html>"""


def generate_markdown_report(
    query: str,
    summary_md: str,
    entities=None,
    search_count: int = 0,
    filtered_count: int = 0,
    scraped_count: int = 0,
) -> str:
    ts = _now()
    lines = [
        f"# Robin OSINT Report",
        f"",
        f"**Query:** `{query}`  ",
        f"**Generated:** {ts}  ",
        f"**Pipeline:** {search_count} found → {filtered_count} filtered → {scraped_count} scraped",
        f"",
        f"---",
        f"",
        summary_md,
        f"",
        f"---",
        f"",
        f"## Extracted IOCs",
    ]
    if entities:
        for attr in ["ipv4", "onions", "domains", "emails", "btc", "eth", "xmr",
                     "cve", "sha256", "sha1", "md5", "telegram", "phones"]:
            vals = getattr(entities, attr, [])
            if vals:
                lines.append(f"\n### {attr.upper()}")
                for v in vals[:30]:
                    lines.append(f"- `{v}`")
    lines.append(f"\n---\n*Generated by Robin OSINT v2 — for authorised research use only.*")
    return "\n".join(lines)
