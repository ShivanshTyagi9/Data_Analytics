"""
scrape.py
Improved Tor-aware web scraper for Robin.

New in v2:
 • Content-quality scoring: filters near-empty pages / CAPTCHAs
 • Honeypot heuristic: flags pages with law-enforcement indicators
 • Language snippet: detects likely language from first 500 chars
 • Structured return: (url, text, meta) instead of bare (url, text)
 • Configurable per-scrape character cap
 • Graceful degrade: returns title-only if scrape fails (same as v1)
"""

import re
import random
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from bs4 import BeautifulSoup
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, List, Tuple, Any

import warnings
warnings.filterwarnings("ignore")

from config import TOR_SOCKS_HOST, TOR_SOCKS_PORT, SCRAPE_TIMEOUT, SCRAPE_MAX_CHARS

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/135.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/135.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/135.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:137.0) Gecko/20100101 Firefox/137.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14.7; rv:137.0) Gecko/20100101 Firefox/137.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_7_5) AppleWebKit/605.1.15 Version/18.3 Safari/605.1.15",
]

# ── Quality / honeypot signals ────────────────────────────────────────────────
_CAPTCHA_SIGNALS = re.compile(
    r"(captcha|cloudflare|ddos.?protect|access.?denied|403.?forbidden|"
    r"challenge.?page|are.?you.?human|verify.?you.?are.?human)", re.I
)
_HONEYPOT_SIGNALS = re.compile(
    r"(this.?site.?is.?operated.?by.?law|federal.?bureau|department.?of.?justice|"
    r"seized.?by|this.?domain.?has.?been.?seized|europol|interpol|"
    r"operation.?led.?by.?law)", re.I
)
_MIN_CONTENT_CHARS = 80   # pages with fewer chars are considered empty


def _get_tor_session() -> requests.Session:
    session = requests.Session()
    retry   = Retry(total=3, read=3, connect=3, backoff_factor=0.3,
                    status_forcelist=[500, 502, 503, 504])
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("http://",  adapter)
    session.mount("https://", adapter)
    session.proxies = {
        "http":  f"socks5h://{TOR_SOCKS_HOST}:{TOR_SOCKS_PORT}",
        "https": f"socks5h://{TOR_SOCKS_HOST}:{TOR_SOCKS_PORT}",
    }
    return session


def _clean_html(html: str) -> str:
    """Parse HTML → clean plain text, strip scripts/styles/nav."""
    soup = BeautifulSoup(html, "html.parser")
    for tag in soup(["script", "style", "nav", "footer", "header", "noscript", "svg"]):
        tag.extract()
    text = soup.get_text(separator=" ")
    return " ".join(text.split())   # collapse whitespace


def _content_quality(text: str) -> Dict[str, Any]:
    """
    Return a quality metadata dict:
      score     float 0..1
      is_captcha bool
      is_honeypot bool
      char_count  int
    """
    is_captcha  = bool(_CAPTCHA_SIGNALS.search(text[:2000]))
    is_honeypot = bool(_HONEYPOT_SIGNALS.search(text[:2000]))
    char_count  = len(text)

    score = 1.0
    if is_captcha or is_honeypot:
        score = 0.0
    elif char_count < _MIN_CONTENT_CHARS:
        score = 0.1
    elif char_count < 500:
        score = 0.4

    return {
        "score":        score,
        "is_captcha":   is_captcha,
        "is_honeypot":  is_honeypot,
        "char_count":   char_count,
    }


def scrape_single(
    url_data: Dict[str, str],
    max_chars: int = SCRAPE_MAX_CHARS,
) -> Tuple[str, str, Dict[str, Any]]:
    """
    Scrape a single URL through Tor (if .onion) or clearweb.
    Returns (url, text, meta) where meta contains quality info.
    """
    url      = url_data["link"]
    title    = url_data.get("title", url)
    use_tor  = ".onion" in url
    headers  = {"User-Agent": random.choice(USER_AGENTS)}
    meta: Dict[str, Any] = {"title": title, "score": 0.0, "is_captcha": False, "is_honeypot": False}

    try:
        if use_tor:
            session  = _get_tor_session()
            response = session.get(url, headers=headers, timeout=SCRAPE_TIMEOUT)
        else:
            response = requests.get(url, headers=headers, timeout=25)

        if response.status_code != 200:
            return url, title, meta

        text    = _clean_html(response.text)
        quality = _content_quality(text)
        meta.update(quality)

        # Truncate to cap
        if len(text) > max_chars:
            text = text[:max_chars] + " ...[truncated]"

        scraped_text = f"{title} — {text}" if text else title
        return url, scraped_text, meta

    except Exception as exc:
        meta["error"] = str(exc)[:120]
        return url, title, meta


def scrape_multiple(
    urls_data: List[Dict[str, str]],
    max_workers: int = 5,
    max_chars: int = SCRAPE_MAX_CHARS,
    skip_honeypots: bool = True,
    skip_captchas:  bool = True,
) -> Dict[str, str]:
    """
    Scrape all URLs concurrently.  Returns a dict {url: text}.
    Pages flagged as honeypots or CAPTCHAs are silently dropped when
    the corresponding skip_* flags are True.
    """
    results: Dict[str, str] = {}

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_map = {
            executor.submit(scrape_single, ud, max_chars): ud
            for ud in urls_data
        }
        for future in as_completed(future_map):
            try:
                url, text, meta = future.result()
                if skip_honeypots and meta.get("is_honeypot"):
                    continue
                if skip_captchas and meta.get("is_captcha"):
                    continue
                results[url] = text
            except Exception:
                continue

    return results


def scrape_with_meta(
    urls_data: List[Dict[str, str]],
    max_workers: int = 5,
    max_chars: int = SCRAPE_MAX_CHARS,
) -> List[Dict[str, Any]]:
    """
    Like scrape_multiple but returns a list of dicts including quality metadata.
    Useful for the UI to display per-page quality info.
    """
    records: List[Dict[str, Any]] = []

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(scrape_single, ud, max_chars) for ud in urls_data]
        for future in as_completed(futures):
            try:
                url, text, meta = future.result()
                records.append({"url": url, "text": text, **meta})
            except Exception:
                pass

    return records
