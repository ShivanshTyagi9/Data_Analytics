"""
search.py
Dark-web and clearweb search module for Robin.

Improvements over v1:
 • 20 onion search engines (was 16)
 • Ahmia.fi clearweb fallback when Tor is unreachable
 • Per-engine result quality scoring (title length, link validity)
 • Configurable max-results per engine to avoid flooding
 • Honeypot / junk-URL heuristics to pre-filter obvious garbage
 • Better HTML parsing that handles more search-engine layouts
"""

import re
import random
import requests
from bs4 import BeautifulSoup
from concurrent.futures import ThreadPoolExecutor, as_completed
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from typing import List, Dict

import warnings
warnings.filterwarnings("ignore")

from config import TOR_SOCKS_HOST, TOR_SOCKS_PORT

# ── User-agent pool ───────────────────────────────────────────────────────────
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/135.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/135.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:137.0) Gecko/20100101 Firefox/137.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14.7; rv:137.0) Gecko/20100101 Firefox/137.0",
    "Mozilla/5.0 (X11; Linux i686; rv:137.0) Gecko/20100101 Firefox/137.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_7_5) AppleWebKit/605.1.15 Version/18.3 Safari/605.1.15",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/135.0.0.0 Safari/537.36 Edg/135.0.3179.54",
]

# ── Onion search-engine registry ─────────────────────────────────────────────
SEARCH_ENGINES: List[Dict[str, str]] = [
    {"name": "Ahmia",           "url": "http://juhanurmihxlp77nkq76byazcldy2hlmovfu2epvl5ankdibsot4csyd.onion/search/?q={query}"},
    {"name": "OnionLand",       "url": "http://3bbad7fauom4d6sgppalyqddsqbf5u5p56b5k5uk2zxsy3d6ey2jobad.onion/search?q={query}"},
    {"name": "Torgle",          "url": "http://iy3544gmoeclh5de6gez2256v6pjh4omhpqdh2wpeeppjtvqmjhkfwad.onion/torgle/?query={query}"},
    {"name": "Amnesia",         "url": "http://amnesia7u5odx5xbwtpnqk3edybgud5bmiagu75bnqx2crntw5kry7ad.onion/search?query={query}"},
    {"name": "Kaizer",          "url": "http://kaizerwfvp5gxu6cppibp7jhcqptavq3iqef66wbxenh6a2fklibdvid.onion/search?q={query}"},
    {"name": "Anima",           "url": "http://anima4ffe27xmakwnseih3ic2y7y3l6e7fucwk4oerdn4odf7k74tbid.onion/search?q={query}"},
    {"name": "Tornado",         "url": "http://tornadoxn3viscgz647shlysdy7ea5zqzwda7hierekeuokh5eh5b3qd.onion/search?q={query}"},
    {"name": "TorNet",          "url": "http://tornetupfu7gcgidt33ftnungxzyfq2pygui5qdoyss34xbgx2qruzid.onion/search?q={query}"},
    {"name": "Torland",         "url": "http://torlbmqwtudkorme6prgfpmsnile7ug2zm4u3ejpcncxuhpu4k2j4kyd.onion/index.php?a=search&q={query}"},
    {"name": "FindTor",         "url": "http://findtorroveq5wdnipkaojfpqulxnkhblymc7aramjzajcvpptd4rjqd.onion/search?q={query}"},
    {"name": "Excavator",       "url": "http://2fd6cemt4gmccflhm6imvdfvli3nf7zn6rfrwpsy7uhxrgbypvwf5fad.onion/search?query={query}"},
    {"name": "Onionway",        "url": "http://oniwayzz74cv2puhsgx4dpjwieww4wdphsydqvf5q7eyz4myjvyw26ad.onion/search.php?s={query}"},
    {"name": "Tor66",           "url": "http://tor66sewebgixwhcqfnp5inzp5x5uohhdy3kvtnyfxc2e5mxiuh34iid.onion/search?q={query}"},
    {"name": "OSS",             "url": "http://3fzh7yuupdfyjhwt3ugzqqof6ulbcl27ecev33knxe3u7goi3vfn2qqd.onion/oss/index.php?search={query}"},
    {"name": "Torgol",          "url": "http://torgolnpeouim56dykfob6jh5r2ps2j73enc42s2um4ufob3ny4fcdyd.onion/?q={query}"},
    {"name": "DeepSearches",    "url": "http://searchgf7gdtauh7bhnbyed4ivxqmuoat3nm6zfrg3ymkq6mtnpye3ad.onion/search?q={query}"},
    {"name": "Haystak",         "url": "http://haystak5njsmn2hqkewecpaxetahtwhsbsa64jom2k22z5afxhnpxfid.onion/?q={query}"},
    {"name": "TorSearch",       "url": "http://torsearchruby56ovtg4a2mf4jl4h2u2zw2bvfqhrwn5biyqkrq2ad.onion/?q={query}"},
    {"name": "Phobos",          "url": "http://phobosxilamwcg75xt22id7aywkeb4tvstocklzdbbgo2b34fmgpzoad.onion/search?query={query}"},
    {"name": "VormWeb",         "url": "http://vormwebgsqonkzjz7lcnfkfpbhxhizaq6m65vz4cvxskrhnhiuqoayd.onion/search.php?search={query}"},
]

DEFAULT_SEARCH_ENGINES = [e["url"] for e in SEARCH_ENGINES]

# ── Honeypot / junk heuristics ────────────────────────────────────────────────
_HONEYPOT_PATTERNS = re.compile(
    r"(federal|fbi|dea|interpol|police|law.?enforce|honeypot|scam.?site|"
    r"fake.?market|exit.?scam|ripper|trusted.?vendor.?list|mirror.?list|"
    r"onion\.link|onion\.cab|onion\.ws|tor2web|torhiddenwiki)", re.I
)
_MIN_TITLE_LEN = 4
_ONION_RE = re.compile(r"https?://[a-z2-7]{16,56}\.onion[^\s\"'<>]*", re.I)


def _quality_score(item: Dict) -> float:
    """Return a rough quality score 0..1 for a search result item."""
    title = item.get("title", "")
    link  = item.get("link", "")
    score = 0.0
    if len(title) >= 10:
        score += 0.4
    elif len(title) >= _MIN_TITLE_LEN:
        score += 0.2
    if re.search(r"[a-z2-7]{56}\.onion", link, re.I):   # v3 onion → better
        score += 0.4
    elif re.search(r"[a-z2-7]{16}\.onion", link, re.I):  # v2 onion
        score += 0.2
    if _HONEYPOT_PATTERNS.search(title) or _HONEYPOT_PATTERNS.search(link):
        score -= 0.8
    return score


# ── Session helpers ───────────────────────────────────────────────────────────

def _tor_session() -> requests.Session:
    session = requests.Session()
    retry = Retry(total=3, read=2, connect=2, backoff_factor=0.4,
                  status_forcelist=[500, 502, 503, 504])
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("http://",  adapter)
    session.mount("https://", adapter)
    session.proxies = {
        "http":  f"socks5h://{TOR_SOCKS_HOST}:{TOR_SOCKS_PORT}",
        "https": f"socks5h://{TOR_SOCKS_HOST}:{TOR_SOCKS_PORT}",
    }
    return session


def _random_headers() -> Dict[str, str]:
    return {"User-Agent": random.choice(USER_AGENTS)}


# ── Per-engine fetch ──────────────────────────────────────────────────────────

def _parse_links(html: str, source_url: str) -> List[Dict[str, str]]:
    """Generic link parser — covers most onion search-engine layouts."""
    soup   = BeautifulSoup(html, "html.parser")
    links  = []

    # Strategy 1: walk all <a> tags
    for a in soup.find_all("a", href=True):
        href  = a["href"]
        title = a.get_text(strip=True)
        # Extract .onion URLs embedded in redirect hrefs (e.g. ?url=http://xxx.onion)
        found = _ONION_RE.findall(href)
        if not found:
            found = _ONION_RE.findall(href)
        # Direct onion href
        if re.search(r"[a-z2-7]+\.onion", href, re.I):
            clean = re.sub(r"(?<=\.onion)\/.*", "", href.split("?url=")[-1])
            if len(title) >= _MIN_TITLE_LEN and "search" not in clean.lower():
                links.append({"title": title, "link": clean.rstrip("/")})
        # Unwrap redirect links
        for url in found:
            clean = re.sub(r"(?<=\.onion)\/.*", "", url)
            if len(title) >= _MIN_TITLE_LEN and "search" not in clean.lower():
                links.append({"title": title, "link": clean.rstrip("/")})

    # Strategy 2: regex sweep of raw HTML for any missed onion URLs
    for m in _ONION_RE.finditer(html):
        raw = m.group(0)
        clean = re.sub(r"(?<=\.onion)\/.*", "", raw).rstrip("/")
        if not any(r["link"] == clean for r in links):
            links.append({"title": clean, "link": clean})

    return links


def fetch_search_results(endpoint: str, query: str, max_per_engine: int = 30) -> List[Dict]:
    url     = endpoint.format(query=requests.utils.quote(query))
    session = _tor_session()
    try:
        response = session.get(url, headers=_random_headers(), timeout=40)
        if response.status_code != 200:
            return []
        links = _parse_links(response.text, url)
        # Score and filter
        scored = [(lnk, _quality_score(lnk)) for lnk in links]
        scored = [(lnk, s) for lnk, s in scored if s > 0]
        scored.sort(key=lambda x: x[1], reverse=True)
        return [lnk for lnk, _ in scored[:max_per_engine]]
    except Exception:
        return []


# ── Clearweb Ahmia fallback ───────────────────────────────────────────────────

def _fetch_ahmia_clearweb(query: str) -> List[Dict]:
    """
    Query Ahmia.fi over the public internet — useful when Tor is unavailable
    or as a supplementary source.
    """
    try:
        r = requests.get(
            "https://ahmia.fi/search/",
            params={"q": query},
            headers=_random_headers(),
            timeout=15,
        )
        if r.status_code != 200:
            return []
        soup    = BeautifulSoup(r.text, "html.parser")
        results = []
        for li in soup.select("li.result")[:30]:
            a = li.find("a", href=True)
            if not a:
                continue
            href  = a["href"]
            title = a.get_text(strip=True)
            if ".onion" in href and len(title) >= _MIN_TITLE_LEN:
                clean = re.sub(r"(?<=\.onion)\/.*", "", href).rstrip("/")
                results.append({"title": title, "link": clean, "source": "ahmia_clearweb"})
        return results
    except Exception:
        return []


# ── Main entry point ──────────────────────────────────────────────────────────

def get_search_results(
    refined_query: str,
    max_workers: int = 8,
    include_clearweb_fallback: bool = True,
) -> List[Dict]:
    """
    Query all onion search engines in parallel + optional clearweb Ahmia.
    Returns a deduplicated, quality-sorted list of results.
    """
    raw: List[Dict] = []

    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = {
            ex.submit(fetch_search_results, eng["url"], refined_query): eng["name"]
            for eng in SEARCH_ENGINES
        }
        if include_clearweb_fallback:
            futures[ex.submit(_fetch_ahmia_clearweb, refined_query)] = "Ahmia-CW"

        for fut in as_completed(futures):
            try:
                raw.extend(fut.result())
            except Exception:
                pass

    # Deduplicate by canonical link
    seen: set = set()
    unique: List[Dict] = []
    for item in raw:
        key = item.get("link", "").rstrip("/").lower()
        if key and key not in seen:
            seen.add(key)
            unique.append(item)

    # Final quality-sort
    unique.sort(key=_quality_score, reverse=True)
    return unique
