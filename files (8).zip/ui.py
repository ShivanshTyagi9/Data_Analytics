"""
ui.py  —  Robin v2 Streamlit interface
Tabs: Search · Entities · Enrichment · OTX & Pastes · Report · Settings
"""

import base64
import json
import time
import streamlit as st
from datetime import datetime

from config import OPENAI_API_KEY, OPENAI_MODEL
from llm_utils import build_llm, BufferedStreamingHandler, get_model_choices, get_model_label
from llm import refine_query, filter_results, generate_summary, PRESET_PROMPTS, get_llm
from scrape import scrape_multiple
from search import get_search_results
from health import check_tor_proxy, check_tor_ip, check_llm_health, check_search_engines
from entities import extract_from_scraped
from osint import (
    search_otx_pulses,
    search_pastes,
    search_ahmia_clearweb,
    bulk_enrich_entities,
)
from report import generate_html_report, generate_markdown_report


# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Robin · Dark Web OSINT",
    page_icon="🕷",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ────────────────────────────────────────────────────────────────
st.markdown("""
<style>
  /* Global palette */
  :root {
    --bg:      #0a1628;
    --bg2:     #0f1f35;
    --border:  #1a2535;
    --green:   #00e676;
    --cyan:    #4fc3f7;
    --amber:   #ffcc02;
    --red:     #ff3b5c;
    --purple:  #ce93d8;
    --text:    #cfd8dc;
    --dim:     #546e7a;
  }
  .stApp { background: var(--bg); }
  section[data-testid="stSidebar"] { background: var(--bg2) !important; border-right: 1px solid var(--border); }
  /* Metric cards */
  div[data-testid="metric-container"] {
    background: var(--bg2); border: 1px solid var(--border);
    border-radius: 8px; padding: 12px;
  }
  /* Hide default streamlit branding */
  #MainMenu, footer, header { visibility: hidden; }
  /* Tab styling */
  .stTabs [data-baseweb="tab-list"] { gap: 4px; background: transparent; }
  .stTabs [data-baseweb="tab"] {
    background: var(--bg2); border: 1px solid var(--border);
    border-radius: 6px 6px 0 0; color: var(--dim) !important;
    padding: 8px 18px; font-size: 12px; letter-spacing: 0.5px;
  }
  .stTabs [aria-selected="true"] {
    background: var(--bg) !important; border-bottom-color: var(--bg) !important;
    color: var(--cyan) !important;
  }
  /* Code blocks */
  code { background: #1a2535 !important; color: #80cbc4 !important; }
  /* Spinner */
  .stSpinner > div { border-top-color: var(--green) !important; }
  /* Entity badge */
  .entity-badge {
    display: inline-block; padding: 2px 8px; border-radius: 10px;
    font-size: 11px; font-family: monospace; margin: 2px;
  }
</style>
""", unsafe_allow_html=True)


# ═══════════════════════════════════════════════════════════════════════════════
# SESSION STATE DEFAULTS
# ═══════════════════════════════════════════════════════════════════════════════
def _init_state():
    defaults = {
        "refined":          "",
        "results":          [],
        "filtered":         [],
        "scraped":          {},
        "entities":         None,
        "enrichment":       {},
        "otx_pulses":       [],
        "pastes":           [],
        "streamed_summary": "",
        "pipeline_done":    False,
        "run_ts":           None,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v
_init_state()


# ═══════════════════════════════════════════════════════════════════════════════
# SIDEBAR
# ═══════════════════════════════════════════════════════════════════════════════
with st.sidebar:
    st.markdown("""
    <div style="padding:12px 0 8px">
      <span style="font-size:22px;font-weight:800;color:#4fc3f7;letter-spacing:3px">ROBIN</span>
      <span style="color:#00e676;font-size:22px;font-weight:800">.</span><br>
      <span style="font-size:10px;color:#546e7a;letter-spacing:2px">DARK WEB OSINT PLATFORM v2</span>
    </div>
    """, unsafe_allow_html=True)
    st.divider()

    # ── Model selection ────────────────────────────────────────────────────────
    st.markdown("**⚙️ Model**")
    model_choices = get_model_choices()
    if not model_choices:
        st.error("❌ OPENAI_API_KEY not set in .env")
        model_id = "gpt-4o-mini"
    else:
        model_id = st.selectbox(
            "OpenAI Model",
            model_choices,
            format_func=get_model_label,
            label_visibility="collapsed",
        )

    # ── Pipeline settings ──────────────────────────────────────────────────────
    st.markdown("**🔧 Pipeline**")
    col1, col2 = st.columns(2)
    threads      = col1.slider("Threads",   1, 16, 5)
    filter_top_k = col2.slider("Top-K",     5, 30, 20)

    use_clearweb_fallback = st.checkbox("Ahmia clearweb fallback", value=True,
        help="Also query Ahmia.fi over regular internet if Tor results are thin.")
    skip_honeypots = st.checkbox("Skip honeypot pages", value=True)
    skip_captchas  = st.checkbox("Skip CAPTCHA pages",  value=True)
    run_enrichment = st.checkbox("Run free OSINT enrichment", value=True,
        help="Enrich IPs/domains via Shodan InternetDB, ip-api, urlscan, OTX (no cost).")

    # ── Prompt settings ────────────────────────────────────────────────────────
    st.divider()
    st.markdown("**📋 Analysis Profile**")
    PRESET_LABELS = {
        "🔍 Threat Intelligence":          "threat_intel",
        "🦠 Ransomware / Malware":          "ransomware_malware",
        "👤 Personal / Identity":           "personal_identity",
        "🏢 Corporate Espionage":           "corporate_espionage",
    }
    preset_label   = st.selectbox("Profile", list(PRESET_LABELS.keys()), label_visibility="collapsed")
    selected_preset = PRESET_LABELS[preset_label]

    with st.expander("System prompt preview"):
        st.text_area("Prompt", PRESET_PROMPTS[selected_preset].strip(),
                     height=150, disabled=True)

    custom_instructions = st.text_area(
        "Custom instructions (optional)",
        placeholder="e.g. Focus on cryptocurrency wallets and exchange mentions.",
        height=80,
    )

    # ── Health checks ──────────────────────────────────────────────────────────
    st.divider()
    st.markdown("**🩺 Health Checks**")

    if st.button("Check Tor + LLM", use_container_width=True):
        with st.spinner("Checking..."):
            tor  = check_tor_proxy()
            llm_h = check_llm_health(model_id)
        if tor["status"] == "up":
            st.success(f"✅ Tor proxy — {tor['latency_ms']}ms")
        else:
            st.error(f"❌ Tor proxy — {tor.get('error','unreachable')}")
        if llm_h["status"] == "up":
            st.success(f"✅ {model_id} — {llm_h['latency_ms']}ms")
        else:
            st.error(f"❌ {model_id} — {llm_h.get('error','')[:80]}")

    if st.button("Check Search Engines", use_container_width=True):
        tor = check_tor_proxy()
        if tor["status"] == "down":
            st.error("❌ Tor proxy unreachable — start Tor first.")
        else:
            with st.spinner("Pinging 20 engines via Tor..."):
                eng_results = check_search_engines()
            up = sum(1 for r in eng_results if r["status"] == "up")
            st.info(f"{up}/{len(eng_results)} engines reachable")
            for r in eng_results:
                icon = "🟢" if r["status"] == "up" else "🔴"
                lat  = f"{r['latency_ms']}ms" if r.get("latency_ms") else r.get("error","")[:30]
                st.markdown(f"{icon} **{r['name']}** — {lat}")

    if st.button("Verify Tor Exit IP", use_container_width=True):
        with st.spinner("Checking via Tor..."):
            result = check_tor_ip()
        if result["status"] == "up" and result["is_tor"]:
            st.success(f"✅ Routing via Tor · Exit IP: {result['exit_ip']}")
        elif result["status"] == "no_tor":
            st.warning(f"⚠️ Not routing via Tor · IP: {result['exit_ip']}")
        else:
            st.error(f"❌ {result.get('error','Failed')}")

    # ── API status summary ─────────────────────────────────────────────────────
    st.divider()
    from config import ABUSEIPDB_KEY, OTX_API_KEY, ETHERSCAN_KEY, URLSCAN_KEY
    def _ok(v): return "✅" if v else "⬜"
    st.markdown(f"""
    <div style="font-size:11px;color:#546e7a;line-height:2">
    {_ok(OPENAI_API_KEY)} OpenAI (required)<br>
    {_ok(OTX_API_KEY)} OTX (optional, free)<br>
    {_ok(ABUSEIPDB_KEY)} AbuseIPDB (optional, free)<br>
    {_ok(URLSCAN_KEY)} urlscan.io (optional, free)<br>
    {_ok(ETHERSCAN_KEY)} Etherscan (optional, free)<br>
    ✅ Shodan InternetDB (always free)<br>
    ✅ ip-api.com (always free)<br>
    ✅ Blockchain.info (always free)<br>
    </div>""", unsafe_allow_html=True)


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN AREA
# ═══════════════════════════════════════════════════════════════════════════════

# ── Logo + search bar ─────────────────────────────────────────────────────────
st.markdown("""
<div style="text-align:center;padding:20px 0 10px">
  <span style="font-size:36px;font-weight:900;color:#4fc3f7;letter-spacing:4px">ROBIN</span>
  <span style="color:#00e676;font-size:36px;font-weight:900">.</span>
  <div style="font-size:11px;color:#546e7a;letter-spacing:3px;margin-top:4px">
    AI-POWERED DARK WEB OSINT · FREE SOURCES · TOR NETWORK
  </div>
</div>
""", unsafe_allow_html=True)

with st.form("search_form", clear_on_submit=False):
    q_col, btn_col = st.columns([8, 1])
    query    = q_col.text_input("", placeholder="Enter threat actor, keyword, domain, CVE, crypto address…",
                                 label_visibility="collapsed")
    run_btn  = btn_col.form_submit_button("🔍 Run", use_container_width=True)

# Quick-select chips
example_queries = ["ransomware C2 2024", "credential dump sale", "zero-day exploit kit", "APT phishing campaign", "data breach database"]
chip_cols = st.columns(len(example_queries))
for col, eq in zip(chip_cols, example_queries):
    if col.button(eq, use_container_width=True):
        query   = eq
        run_btn = True

# ═══════════════════════════════════════════════════════════════════════════════
# PIPELINE
# ═══════════════════════════════════════════════════════════════════════════════
if run_btn and query.strip():
    # Reset state
    for k in ["refined","results","filtered","scraped","entities","enrichment",
              "otx_pulses","pastes","streamed_summary","pipeline_done"]:
        st.session_state[k] = [] if isinstance(st.session_state.get(k), list) else \
                               {} if isinstance(st.session_state.get(k), dict) else \
                               None if k in ("entities",) else ""
    st.session_state["pipeline_done"] = False
    st.session_state["run_ts"] = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")

    progress_container = st.container()
    with progress_container:
        prog  = st.progress(0, text="🔄 Initialising…")
        status = st.empty()

        # Stage 1 – Load LLM
        status.info("🔄 Connecting to OpenAI…")
        try:
            llm_plain = build_llm(model_id, streaming=False)
        except Exception as e:
            st.error(f"❌ LLM init failed: {e}")
            st.stop()
        prog.progress(10, text="✅ LLM connected")

        # Stage 2 – Refine query
        status.info("✏️ Refining search query…")
        try:
            st.session_state.refined = refine_query(llm_plain, query)
        except Exception as e:
            st.error(f"❌ Query refinement failed: {e}")
            st.stop()
        prog.progress(20, text=f"✅ Refined: {st.session_state.refined}")

        # Stage 3 – Dark-web search
        status.info(f"🌑 Searching dark web for: **{st.session_state.refined}**…")
        raw_results = get_search_results(
            st.session_state.refined,
            max_workers=threads,
            include_clearweb_fallback=use_clearweb_fallback,
        )
        st.session_state.results = raw_results
        prog.progress(40, text=f"✅ Found {len(raw_results)} raw results")

        # Stage 4 – Filter
        status.info(f"🗂️ LLM filtering top {filter_top_k} results…")
        filtered = filter_results(llm_plain, st.session_state.refined, raw_results)
        st.session_state.filtered = filtered[:filter_top_k]
        prog.progress(55, text=f"✅ Filtered to {len(st.session_state.filtered)} results")

        # Stage 5 – Scrape
        status.info("📜 Scraping onion pages via Tor…")
        scraped = scrape_multiple(
            st.session_state.filtered,
            max_workers=threads,
            skip_honeypots=skip_honeypots,
            skip_captchas=skip_captchas,
        )
        st.session_state.scraped = scraped
        prog.progress(70, text=f"✅ Scraped {len(scraped)} pages")

        # Stage 6 – Entity extraction
        status.info("🔬 Extracting IOCs and artefacts…")
        ents = extract_from_scraped(scraped)
        st.session_state.entities = ents
        prog.progress(78, text=f"✅ {ents.total()} artefacts extracted")

        # Stage 7 – Free OSINT enrichment
        if run_enrichment and ents.total() > 0:
            status.info("🌐 Running free OSINT enrichment (Shodan, ip-api, OTX, urlscan)…")
            enrichment = bulk_enrich_entities(ents)
            st.session_state.enrichment = enrichment
        prog.progress(84, text="✅ Enrichment done")

        # Stage 8 – OTX pulses + pastes
        status.info("📡 Fetching OTX pulses and paste-site hits…")
        st.session_state.otx_pulses = search_otx_pulses(st.session_state.refined, limit=10)
        st.session_state.pastes     = search_pastes(st.session_state.refined)
        prog.progress(88, text="✅ Threat intelligence feeds queried")

        # Stage 9 – AI summary (streaming)
        status.info("✍️ Generating AI intelligence report…")

        def _update_summary(chunk: str):
            st.session_state.streamed_summary += chunk

        stream_handler = BufferedStreamingHandler(ui_callback=_update_summary)
        llm_stream = build_llm(model_id, streaming=True, ui_callback=_update_summary)
        try:
            generate_summary(
                llm_stream, query, scraped,
                preset=selected_preset,
                custom_instructions=custom_instructions,
            )
        except Exception as e:
            st.session_state.streamed_summary += f"\n\n⚠️ Summary error: {e}"

        prog.progress(100, text="✅ Pipeline complete!")
        status.success(f"✔️ Scan complete · {len(scraped)} pages · {ents.total()} artefacts · {len(st.session_state.otx_pulses)} OTX pulses")
        st.session_state.pipeline_done = True


# ═══════════════════════════════════════════════════════════════════════════════
# RESULTS TABS
# ═══════════════════════════════════════════════════════════════════════════════
if st.session_state.pipeline_done or st.session_state.streamed_summary:

    # Top metrics
    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Raw Results",   len(st.session_state.results))
    c2.metric("Filtered",      len(st.session_state.filtered))
    c3.metric("Pages Scraped", len(st.session_state.scraped))
    ents = st.session_state.entities
    c4.metric("IOC Artefacts", ents.total() if ents else 0)
    c5.metric("OTX Pulses",    len(st.session_state.otx_pulses))

    st.markdown(f"*Query: `{st.session_state.refined}` · Run: {st.session_state.run_ts}*")

    tab_search, tab_entities, tab_enrich, tab_feeds, tab_report = st.tabs([
        "🔍 Search Results",
        "🔬 IOC Artefacts",
        "🌐 Enrichment",
        "📡 OTX & Pastes",
        "📄 Report",
    ])

    # ── TAB 1: Search Results ─────────────────────────────────────────────────
    with tab_search:
        st.markdown("#### Intelligence Report")
        st.markdown(st.session_state.streamed_summary or "*Generating…*")

        st.divider()
        col_a, col_b = st.columns(2)
        with col_a:
            st.markdown(f"#### Raw Results ({len(st.session_state.results)})")
            for i, r in enumerate(st.session_state.results[:40], 1):
                with st.expander(f"{i}. {r.get('title','(no title)')[:70]}"):
                    st.code(r.get("link",""), language="text")
        with col_b:
            st.markdown(f"#### Filtered Results ({len(st.session_state.filtered)})")
            for i, r in enumerate(st.session_state.filtered, 1):
                with st.expander(f"{i}. {r.get('title','(no title)')[:70]}"):
                    st.code(r.get("link",""), language="text")
                    url = r.get("link","")
                    if url in st.session_state.scraped:
                        snippet = st.session_state.scraped[url][:400]
                        st.caption(snippet)

    # ── TAB 2: IOC Artefacts ──────────────────────────────────────────────────
    with tab_entities:
        if ents and ents.total() > 0:
            st.markdown(f"### {ents.total()} Artefacts Extracted")

            ENTITY_CFG = [
                ("🌐 IPv4 Addresses",    "ipv4",    "#4fc3f7"),
                ("🧅 Onion Addresses",   "onions",  "#ce93d8"),
                ("🔗 Domains",           "domains", "#80cbc4"),
                ("📧 Emails",            "emails",  "#ffcc02"),
                ("₿ Bitcoin (BTC)",      "btc",     "#f7931a"),
                ("Ξ Ethereum (ETH)",     "eth",     "#627eea"),
                ("⬡ Monero (XMR)",       "xmr",     "#ff6600"),
                ("⚠️ CVEs",              "cve",     "#ff5252"),
                ("🔑 SHA-256 Hashes",    "sha256",  "#90a4ae"),
                ("🔑 SHA-1 Hashes",      "sha1",    "#90a4ae"),
                ("🔑 MD5 Hashes",        "md5",     "#90a4ae"),
                ("✈️ Telegram",          "telegram","#2ca5e0"),
                ("📞 Phones",            "phones",  "#aed581"),
            ]
            cols_per_row = 2
            rows = [ENTITY_CFG[i:i+cols_per_row] for i in range(0, len(ENTITY_CFG), cols_per_row)]
            for row in rows:
                cols = st.columns(cols_per_row)
                for col, (label, attr, color) in zip(cols, row):
                    vals = getattr(ents, attr, [])
                    if vals:
                        with col:
                            st.markdown(f"**{label}** `{len(vals)}`")
                            badges = " ".join(
                                f'<span class="entity-badge" style="background:{color}22;color:{color};border:1px solid {color}55">{v}</span>'
                                for v in vals[:20]
                            )
                            st.markdown(badges, unsafe_allow_html=True)
                            if len(vals) > 20:
                                st.caption(f"+{len(vals)-20} more")
        else:
            st.info("No artefacts found — try a more specific query or ensure Tor is routing correctly.")

    # ── TAB 3: OSINT Enrichment ───────────────────────────────────────────────
    with tab_enrich:
        enrichment = st.session_state.enrichment
        if not enrichment:
            st.info("Enable **'Run free OSINT enrichment'** in the sidebar to see enrichment data here.")
        else:
            # IP enrichment
            if enrichment.get("ips"):
                st.markdown("### 🌐 IP Intelligence")
                for ip_data in enrichment["ips"]:
                    ip = ip_data.get("ip","?")
                    with st.expander(f"🖥 {ip}"):
                        col1, col2, col3 = st.columns(3)
                        col1.metric("Country",  ip_data.get("country","?"))
                        col2.metric("ASN",       ip_data.get("asn","?"))
                        col3.metric("Proxy/VPN", "Yes" if ip_data.get("is_proxy") else "No")
                        ports = ip_data.get("ports", [])
                        vulns = ip_data.get("vulns", [])
                        if ports: st.markdown(f"**Open Ports:** {', '.join(str(p) for p in ports[:20])}")
                        if vulns:
                            st.markdown(f"**Vulnerabilities ({len(vulns)}):**")
                            for v in vulns[:10]:
                                st.code(v, language="text")
                        if ip_data.get("abuse_score") is not None:
                            st.metric("AbuseIPDB Score", ip_data.get("abuse_score"))

            # Domain enrichment
            if enrichment.get("domains"):
                st.markdown("### 🔗 Domain Intelligence")
                for d in enrichment["domains"]:
                    src = d.get("source","")
                    with st.expander(f"🌐 {src}"):
                        if d.get("total_scans"):
                            st.metric("urlscan.io hits", d["total_scans"])
                            for scan in d.get("recent_scans",[]):
                                mal = "🔴 MALICIOUS" if scan.get("malicious") else "🟢 Clean"
                                st.markdown(f"- {mal} `{scan.get('url','')[:80]}`")
                        if d.get("pulse_count"):
                            st.metric("OTX Pulses", d["pulse_count"])
                        if d.get("malware_families"):
                            st.markdown(f"**Malware:** {', '.join(d['malware_families'])}")

            # Crypto enrichment
            if enrichment.get("btc"):
                st.markdown("### ₿ Bitcoin Addresses")
                for btc in enrichment["btc"]:
                    with st.expander(f"₿ {btc.get('address','?')[:20]}…"):
                        col1, col2, col3 = st.columns(3)
                        col1.metric("Balance (BTC)",  round(btc.get("balance_btc",0), 8))
                        col2.metric("Total Rcv (BTC)", round(btc.get("total_received_btc",0), 8))
                        col3.metric("Tx Count",        btc.get("tx_count",0))

            if enrichment.get("eth"):
                st.markdown("### Ξ Ethereum Addresses")
                for eth in enrichment["eth"]:
                    with st.expander(f"Ξ {eth.get('address','?')[:20]}…"):
                        st.metric("Balance (ETH)", eth.get("balance_eth",0))
                        st.markdown(f"[View on Etherscan]({eth.get('explorer_url','#')})")

    # ── TAB 4: OTX + Pastes ───────────────────────────────────────────────────
    with tab_feeds:
        col_otx, col_paste = st.columns(2)

        with col_otx:
            st.markdown("### 🛸 AlienVault OTX Pulses")
            pulses = st.session_state.otx_pulses
            if pulses:
                for p in pulses:
                    with st.expander(p.get("name","?")[:60]):
                        c1, c2 = st.columns(2)
                        c1.metric("Indicators", p.get("indicator_count",0))
                        c2.metric("TLP",        (p.get("tlp") or "WHITE").upper())
                        if p.get("adversary"):   st.markdown(f"**Adversary:** {p['adversary']}")
                        if p.get("malware_families"): st.markdown(f"**Malware:** {', '.join(p['malware_families'])}")
                        if p.get("tags"):         st.markdown(f"**Tags:** {', '.join(p['tags'])}")
                        st.markdown(f"[View Pulse]({p.get('url','#')})")
            else:
                st.info("No OTX pulses found. Add OTX_API_KEY to .env for higher rate limits.")

        with col_paste:
            st.markdown("### 📋 Paste Site Hits")
            pastes = st.session_state.pastes
            if pastes:
                for p in pastes:
                    with st.expander(f"Paste {p.get('id','?')}"):
                        st.caption(p.get("snippet","")[:200])
                        st.markdown(f"[View on Pastebin]({p.get('url','#')})")
            else:
                st.info("No paste-site hits found for this query.")

    # ── TAB 5: Report ─────────────────────────────────────────────────────────
    with tab_report:
        st.markdown("### Export Investigation Report")

        col_dl1, col_dl2 = st.columns(2)

        # Markdown export
        md_report = generate_markdown_report(
            query=query or st.session_state.refined,
            summary_md=st.session_state.streamed_summary,
            entities=st.session_state.entities,
            search_count=len(st.session_state.results),
            filtered_count=len(st.session_state.filtered),
            scraped_count=len(st.session_state.scraped),
        )
        ts   = datetime.now().strftime("%Y%m%d_%H%M%S")
        b64  = base64.b64encode(md_report.encode()).decode()
        col_dl1.markdown(
            f'<a href="data:text/markdown;base64,{b64}" download="robin_report_{ts}.md">'
            f'<button style="width:100%;padding:10px;background:#0f1f35;border:1px solid #4fc3f7;'
            f'color:#4fc3f7;border-radius:6px;cursor:pointer;font-size:13px">⬇ Download Markdown</button></a>',
            unsafe_allow_html=True,
        )

        # HTML export
        html_report = generate_html_report(
            query=query or st.session_state.refined,
            summary_md=st.session_state.streamed_summary,
            entities=st.session_state.entities,
            enrichment=st.session_state.enrichment,
            otx_pulses=st.session_state.otx_pulses,
            pastes=st.session_state.pastes,
            search_count=len(st.session_state.results),
            filtered_count=len(st.session_state.filtered),
            scraped_count=len(st.session_state.scraped),
        )
        b64h = base64.b64encode(html_report.encode()).decode()
        col_dl2.markdown(
            f'<a href="data:text/html;base64,{b64h}" download="robin_report_{ts}.html">'
            f'<button style="width:100%;padding:10px;background:#0f1f35;border:1px solid #00e676;'
            f'color:#00e676;border-radius:6px;cursor:pointer;font-size:13px">⬇ Download HTML Report</button></a>',
            unsafe_allow_html=True,
        )

        st.divider()
        st.markdown("#### Markdown Preview")
        st.markdown(st.session_state.streamed_summary)

        st.divider()
        if st.session_state.entities and st.session_state.entities.total() > 0:
            st.markdown("#### IOC JSON Export")
            ent_dict = st.session_state.entities.as_dict()
            st.json(ent_dict)
            j64 = base64.b64encode(json.dumps(ent_dict, indent=2).encode()).decode()
            st.markdown(
                f'<a href="data:application/json;base64,{j64}" download="iocs_{ts}.json">'
                f'<button style="padding:8px 20px;background:#0f1f35;border:1px solid #ce93d8;'
                f'color:#ce93d8;border-radius:6px;cursor:pointer;font-size:12px">⬇ Download IOCs JSON</button></a>',
                unsafe_allow_html=True,
            )

elif not run_btn:
    # Welcome / onboarding screen
    st.markdown("""
    <div style="text-align:center;padding:40px 0;color:#546e7a">
      <div style="font-size:48px;margin-bottom:16px">🕷</div>
      <div style="font-size:14px;letter-spacing:1px">Enter a query above to begin your investigation.</div>
      <div style="font-size:12px;margin-top:16px;max-width:600px;margin-inline:auto;line-height:2">
        <b style="color:#4fc3f7">Sources:</b> 20 onion search engines · Ahmia.fi · AlienVault OTX ·
        Shodan InternetDB · ip-api.com · urlscan.io · psbdmp.ws · Blockchain.info · Etherscan<br>
        <b style="color:#00e676">All enrichment sources are free.</b>
        Only OpenAI API key required (for LLM steps).
      </div>
    </div>

    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;max-width:800px;margin:24px auto">
      <div style="background:#0f1f35;border:1px solid #1a2535;border-radius:8px;padding:16px;text-align:center">
        <div style="font-size:24px;margin-bottom:8px">🌑</div>
        <div style="font-size:12px;color:#4fc3f7;font-weight:600;margin-bottom:4px">Dark Web Search</div>
        <div style="font-size:11px;color:#546e7a">20 onion search engines queried in parallel via Tor</div>
      </div>
      <div style="background:#0f1f35;border:1px solid #1a2535;border-radius:8px;padding:16px;text-align:center">
        <div style="font-size:24px;margin-bottom:8px">🔬</div>
        <div style="font-size:12px;color:#00e676;font-weight:600;margin-bottom:4px">IOC Extraction</div>
        <div style="font-size:11px;color:#546e7a">IPs, domains, emails, crypto wallets, CVEs, hashes, PGP</div>
      </div>
      <div style="background:#0f1f35;border:1px solid #1a2535;border-radius:8px;padding:16px;text-align:center">
        <div style="font-size:24px;margin-bottom:8px">🌐</div>
        <div style="font-size:12px;color:#ce93d8;font-weight:600;margin-bottom:4px">Free Enrichment</div>
        <div style="font-size:11px;color:#546e7a">Shodan · ip-api · OTX · urlscan · blockchain explorers</div>
      </div>
    </div>
    """, unsafe_allow_html=True)
