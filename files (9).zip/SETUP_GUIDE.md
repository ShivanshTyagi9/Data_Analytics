# Robin v2 — Complete Setup & Safety Guide

---

## Table of Contents

1. [Why Docker?](#1-why-docker)
2. [Security Principles](#2-security-principles)
3. [Prerequisites](#3-prerequisites)
4. [Docker Setup (Recommended)](#4-docker-setup-recommended)
5. [Manual / Local Setup](#5-manual--local-setup)
6. [API Keys Setup](#6-api-keys-setup)
7. [Verifying Tor Is Working](#7-verifying-tor-is-working)
8. [Operational Security (OpSec)](#8-operational-security-opsec)
9. [What Robin Does NOT Do](#9-what-robin-does-not-do)
10. [Troubleshooting](#10-troubleshooting)
11. [Cost Estimate](#11-cost-estimate)

---

## 1. Why Docker?

**Yes — Docker is strongly recommended for Robin.**

Here is exactly what Docker gives you and why it matters for OSINT work:

### Isolation
Your Robin instance runs inside a container that is cut off from the rest of your
operating system. If a malicious onion page somehow exploited a scraping
vulnerability, the blast radius is limited to the container — not your host machine,
not your files, not your real IP address.

### Consistent Tor routing
Tor runs *inside* the container alongside the app. This means:
- All traffic from the scraper goes through Tor automatically
- There is no risk of forgetting to start Tor before running the app
- No other app on your host can interfere with or share the Tor circuit

### No dependency pollution
Robin requires specific Python package versions. Docker isolates these completely —
no conflicts with anything else on your machine.

### Easy teardown
`docker compose down` removes everything. No residual processes, no leftover state.

### Port binding to loopback only
In `docker-compose.yml`, the Streamlit port is bound to `127.0.0.1:8501` — meaning
only your local machine can reach it. No one on your LAN, VPN, or internet can
accidentally reach your Robin instance.

---

## 2. Security Principles

Before running any OSINT tool, understand these fundamentals:

### Your IP is protected by Tor — but only for scraping
- All dark-web scraping goes through Tor
- API calls to OpenAI, OTX, Shodan, etc. go over your **regular internet connection**
  — those services will see your real IP
- This is intentional and acceptable: those are legitimate public APIs

### What Tor protects you from
- Onion sites knowing your real IP address
- Your ISP knowing which onion sites you visited

### What Tor does NOT protect you from
- Logging in to personal accounts while Tor is running (correlation attack)
- Your DNS queries leaking to your ISP (Robin uses `socks5h://` which resolves DNS
  through Tor, so this is handled)
- Timing correlation if you're a high-value target (not relevant for typical research)

### The tool is read-only
Robin only **reads** dark web content. It does not post, register, or interact with
any site. Your footprint is a read-only HTTP GET, routed through Tor, with a random
user-agent.

---

## 3. Prerequisites

### Option A: Docker (recommended)

| Requirement | Version | Check |
|-------------|---------|-------|
| Docker Engine | 24+ | `docker --version` |
| Docker Compose | v2 (plugin) | `docker compose version` |
| RAM | ≥ 2 GB free | `free -h` |
| Disk | ≥ 2 GB free | `df -h` |

**Install Docker:**
```bash
# Linux (Ubuntu/Debian)
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
# Log out and back in

# macOS
# Download Docker Desktop from https://www.docker.com/products/docker-desktop/

# Windows
# Download Docker Desktop; enable WSL 2 backend
```

### Option B: Local Python

| Requirement | Version | Check |
|-------------|---------|-------|
| Python | 3.10+ | `python3 --version` |
| pip | latest | `pip --version` |
| Tor | any | `tor --version` |

---

## 4. Docker Setup (Recommended)

### Step 1 — Clone / organise your files

```
robin/
├── Dockerfile
├── docker-compose.yml
├── docker-entrypoint.sh
├── torrc
├── requirements.txt
├── .env.example
├── .gitignore
├── config.py
├── ui.py
├── llm.py
├── llm_utils.py
├── search.py
├── scrape.py
├── entities.py
├── osint.py
├── health.py
└── report.py
```

### Step 2 — Create your .env file

```bash
cp .env.example .env
```

Open `.env` and set at minimum:

```env
OPENAI_API_KEY=sk-your-actual-key-here
```

Add any optional free keys (OTX, AbuseIPDB, etc.) for richer results.

### Step 3 — Build the image

```bash
docker compose build
```

This will:
1. Pull the Python 3.11 base image
2. Install Tor inside the container
3. Install all Python dependencies
4. Copy your application code

Build takes 2–4 minutes the first time. Subsequent builds are cached and take seconds.

### Step 4 — Run

```bash
# Foreground (see logs in terminal)
docker compose up

# Background (recommended for long sessions)
docker compose up -d
```

### Step 5 — Open Robin

```
http://localhost:8501
```

### Step 6 — Stop

```bash
docker compose down          # stop and remove containers
docker compose down -v       # also remove Tor state volume (forces new circuits)
```

### Useful commands

```bash
# View live logs
docker compose logs -f robin

# Check container health
docker compose ps

# Get a shell inside the container (for debugging)
docker compose exec robin bash

# Rebuild after code changes
docker compose up --build

# Update base image
docker compose pull && docker compose up --build
```

---

## 5. Manual / Local Setup

Use this if you can't use Docker (e.g. on a server without Docker installed).

### Step 1 — Install Tor

**Ubuntu / Debian:**
```bash
sudo apt update && sudo apt install tor -y
sudo systemctl enable tor
sudo systemctl start tor
# Verify:
sudo systemctl status tor
```

**macOS:**
```bash
brew install tor
brew services start tor
# Verify:
brew services list | grep tor
```

**Windows:**
Download Tor Expert Bundle from https://www.torproject.org/download/tor/
Run `tor.exe` — it will listen on 127.0.0.1:9050 by default.

### Step 2 — Install Python dependencies

```bash
# Create a virtual environment (strongly recommended)
python3 -m venv .venv
source .venv/bin/activate        # Linux/macOS
# .venv\Scripts\activate         # Windows

pip install --upgrade pip
pip install -r requirements.txt
```

### Step 3 — Configure environment

```bash
cp .env.example .env
# Edit .env with your API keys
```

### Step 4 — Run

```bash
source .venv/bin/activate
streamlit run ui.py --server.port 8501
```

Open `http://localhost:8501`

---

## 6. API Keys Setup

### OpenAI (required)

1. Go to https://platform.openai.com/api-keys
2. Click **Create new secret key**
3. Copy the key — it starts with `sk-`
4. Add to `.env`: `OPENAI_API_KEY=sk-...`

**Recommended model:** `gpt-4o-mini` — costs ~$0.002 per scan, fast, more than sufficient.
Use `gpt-4o` for more complex analysis.

### AlienVault OTX (optional, free)

1. Go to https://otx.alienvault.com
2. Create a free account
3. Go to **Settings → API Integration**
4. Copy your API key
5. Add to `.env`: `OTX_API_KEY=...`

Without a key, OTX still works but at a lower rate limit.

### AbuseIPDB (optional, free)

1. Go to https://www.abuseipdb.com
2. Create a free account (1,000 IP checks per day)
3. Go to **Account → API**
4. Create a key and copy it
5. Add to `.env`: `ABUSEIPDB_KEY=...`

### urlscan.io (optional, free)

1. Go to https://urlscan.io
2. Create a free account
3. Go to **Settings → API Keys**
4. Add to `.env`: `URLSCAN_KEY=...`

### Etherscan (optional, free)

1. Go to https://etherscan.io
2. Create a free account
3. Go to **My Account → API Keys → Add**
4. Add to `.env`: `ETHERSCAN_KEY=...`

---

## 7. Verifying Tor Is Working

### In Robin's UI
Use the **Health Checks** panel in the left sidebar:

1. **Check Tor + LLM** — verifies the SOCKS proxy is listening and OpenAI is reachable
2. **Verify Tor Exit IP** — makes a real request through Tor to `check.torproject.org`
   and shows your exit node IP. If it says "IsTor: true" you're good.
3. **Check Search Engines** — pings all 20 onion engines via Tor

### Manual check (Docker)
```bash
# Get a shell in the running container
docker compose exec robin bash

# Check if Tor port is open
nc -z 127.0.0.1 9050 && echo "Tor OK" || echo "Tor NOT running"

# Check your Tor exit IP
curl --socks5-hostname 127.0.0.1:9050 https://check.torproject.org/api/ip
# Should return: {"IsTor":true,"IP":"x.x.x.x"}

# Check your real IP (should be DIFFERENT from above)
curl https://api.ipify.org
```

### Manual check (local install)
```bash
# Same commands as above but run directly in your terminal
curl --socks5-hostname 127.0.0.1:9050 https://check.torproject.org/api/ip
```

---

## 8. Operational Security (OpSec)

These practices are important for anyone doing serious OSINT research.

### Network hygiene

**DO:**
- Run Robin on a dedicated machine or VM if possible
- Use a VPN before Tor for extra ISP-level privacy (VPN → Tor)
  — prevents your ISP from knowing you're using Tor at all
- Keep Docker and Tor updated
- Bind Streamlit to `127.0.0.1` only (already done in `docker-compose.yml`)

**DON'T:**
- Don't log into personal accounts (Google, GitHub, etc.) while Robin is running
  on the same browser
- Don't share your `.env` file or API keys
- Don't expose port 8501 to the internet or your LAN
- Don't run Robin as root

### API key safety
- Your OpenAI key is used server-side inside the container — it is never exposed
  to the browser
- Treat your `.env` file like a password — never commit it to git
  (`.gitignore` already excludes it)
- Set OpenAI spending limits at https://platform.openai.com/account/limits

### VM / dedicated machine (advanced)
For the most sensitive research, run Robin on a dedicated VM:
```
Your Machine → VM (Whonix Gateway or Kali) → Docker → Tor → Onion Sites
```
Whonix OS (https://www.whonix.org) is purpose-built for this and routes ALL traffic
through Tor at the OS level — an extra safety net even if Tor inside Docker fails.

### Keeping a clean audit trail
For professional OSINT work, always:
1. Export your report (HTML or Markdown) immediately after each scan
2. Note the timestamp and query in a log
3. Keep exported reports in an encrypted folder (VeraCrypt, encrypted volume, etc.)

---

## 9. What Robin Does NOT Do

To be clear about what this tool is and is not:

- ✅ Reads publicly visible content from onion search engine results
- ✅ Scrapes onion pages the same way a browser would
- ✅ Enriches data using legitimate public APIs
- ✅ Extracts IOCs from text using regex
- ✅ Generates AI analysis of what was found

- ❌ Does NOT access any site that requires login or registration
- ❌ Does NOT download or store files from dark web sites
- ❌ Does NOT interact with, post to, or buy from any market
- ❌ Does NOT attempt to de-anonymise Tor hidden services
- ❌ Does NOT bypass any authentication
- ❌ Does NOT store any scraped content beyond the current session

---

## 10. Troubleshooting

### Tor won't start (Docker)
```bash
# Check Docker logs
docker compose logs robin | grep -i tor

# Common fix: Tor data directory permissions
docker compose down -v
docker compose up --build
```

### Tor won't start (local)
```bash
# Check Tor status
sudo systemctl status tor

# Check Tor logs
sudo journalctl -u tor -n 50

# Common causes:
# - Port 9050 already in use: sudo lsof -i :9050
# - Config error: tor --verify-config -f /etc/tor/torrc
```

### "Connection refused" on port 9050
```bash
# Tor is not running. Start it:
sudo systemctl start tor           # Linux
brew services start tor            # macOS
# Then recheck: nc -z 127.0.0.1 9050
```

### No search results returned
- Most onion search engines have varying uptime. This is normal.
- Run **Check Search Engines** in the sidebar to see which ones are up
- The Ahmia.fi clearweb fallback should always return some results
- Try a simpler query (fewer words)

### OpenAI errors
- `AuthenticationError` → check your `OPENAI_API_KEY` in `.env`
- `RateLimitError` → you've hit your API rate limit; wait a minute
- `InsufficientQuotaError` → add billing at https://platform.openai.com/account/billing

### CAPTCHA / blocked pages
This is normal. Many onion sites return CAPTCHAs to automated requests.
Robin's scraper detects these and silently drops them (when "Skip CAPTCHA pages" is enabled).

### Slow performance
- Tor is inherently slow (100–500ms per hop). This is normal and expected.
- Reduce **Threads** in the sidebar if you see connection errors
- Consider increasing `SCRAPE_TIMEOUT` in `.env` to 60s for very slow sites

---

## 11. Cost Estimate

Robin is designed to be nearly free. The only ongoing cost is OpenAI.

| Component | Cost |
|-----------|------|
| Docker + Tor | Free |
| AlienVault OTX | Free (optional key) |
| Shodan InternetDB | Free forever |
| ip-api.com | Free (45 req/min) |
| AbuseIPDB | Free (1k checks/day) |
| urlscan.io | Free |
| psbdmp.ws | Free |
| Blockchain.info | Free |
| Etherscan | Free |
| **OpenAI gpt-4o-mini** | **~$0.001–0.005 per scan** |
| OpenAI gpt-4o | ~$0.01–0.05 per scan |

A typical Robin scan (refine query + filter 30 results + summarise 10 pages) costs
approximately **$0.002–0.01** using `gpt-4o-mini`. Running 100 scans per month
costs about **$0.20–$1.00**.

---

*Robin v2 — for authorised security research use only.*
