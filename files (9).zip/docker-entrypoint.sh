#!/bin/bash
set -e

echo "=================================================="
echo "  Robin v2 — Dark Web OSINT Platform"
echo "=================================================="

# ── 1. Start Tor daemon (as root via sudo/su, then drop back) ─────────────────
echo "[*] Starting Tor..."
# Run Tor as the debian-tor user, in background
su -s /bin/sh debian-tor -c "tor -f /etc/tor/torrc &"

# ── 2. Wait for Tor SOCKS port to be ready ────────────────────────────────────
echo "[*] Waiting for Tor SOCKS proxy on port 9050..."
MAX_WAIT=60
COUNT=0
while ! nc -z 127.0.0.1 9050 2>/dev/null; do
  sleep 1
  COUNT=$((COUNT + 1))
  if [ "$COUNT" -ge "$MAX_WAIT" ]; then
    echo "[!] Tor did not start within ${MAX_WAIT}s — continuing anyway."
    echo "[!] Check 'docker logs' and ensure Tor is not blocked."
    break
  fi
done

if nc -z 127.0.0.1 9050 2>/dev/null; then
  echo "[✓] Tor SOCKS proxy is ready (${COUNT}s)"
else
  echo "[!] Tor SOCKS proxy not available — dark web search will fail."
fi

# ── 3. Load .env if present ───────────────────────────────────────────────────
if [ -f /app/.env ]; then
  export $(grep -v '^#' /app/.env | grep -v '^$' | xargs)
  echo "[✓] Environment loaded from .env"
fi

# ── 4. Validate OpenAI key ───────────────────────────────────────────────────
if [ -z "$OPENAI_API_KEY" ]; then
  echo ""
  echo "  ┌─────────────────────────────────────────────────────────┐"
  echo "  │  WARNING: OPENAI_API_KEY is not set.                    │"
  echo "  │  LLM features (query refinement, filtering, summary)    │"
  echo "  │  will be unavailable.                                   │"
  echo "  │                                                         │"
  echo "  │  Set it in your .env file or via Docker env var:        │"
  echo "  │    -e OPENAI_API_KEY=sk-...                             │"
  echo "  └─────────────────────────────────────────────────────────┘"
  echo ""
fi

# ── 5. Start Streamlit ────────────────────────────────────────────────────────
echo "[*] Starting Robin Streamlit UI on port 8501..."
echo "[*] Open: http://localhost:8501"
echo ""

exec streamlit run /app/ui.py \
  --server.port=8501 \
  --server.address=0.0.0.0 \
  --server.headless=true \
  --server.fileWatcherType=none \
  --browser.gatherUsageStats=false \
  --server.enableCORS=false \
  --server.enableXsrfProtection=true
